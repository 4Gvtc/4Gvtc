# SwiftRide Bordeaux — mise en prod réelle

Ce dossier contient une vraie app (pas une démo) : Firebase Auth + Firestore en temps
réel, Cloud Functions, paiements Stripe réels, carte live Google Maps (Places, Directions, Geocoding),
et tout le nécessaire pour publier sur le Play Store / App Store.

## 1. Créer le projet Firebase
1. https://console.firebase.google.com → **Ajouter un projet**.
2. Activer **Authentication** → onglet Sign-in method → activer **Anonyme**,
   **E-mail/mot de passe**, **Google**, et **Apple** (Apple nécessite un compte
   Apple Developer à 99 $/an ; sans ça, laissez-le désactivé et gardez juste
   Google + e-mail/mot de passe — le bouton Apple dans l'app échouera proprement).
3. Activer **Firestore Database** (mode production).
4. Activer **Functions** (nécessite le plan Blaze, pay-as-you-go — obligatoire pour
   appeler des API externes comme Stripe).
5. Project settings → **Ajouter une application Web** → copier l'objet `firebaseConfig`.

## 2. Configurer le client
Ouvrir `firebase-init.js` et remplacer :
- `firebaseConfig` par l'objet copié à l'étape 1.5.
- `STRIPE_PUBLISHABLE_KEY` par votre clé publique Stripe (`pk_live_...` ou `pk_test_...`
  pour tester d'abord).

Ouvrir `index.html` et remplacer `YOUR_GOOGLE_MAPS_API_KEY` (dans le `<script src="https://maps.googleapis.com/maps/api/js?...">`
juste avant `</body>`) par votre clé Google Maps :
1. https://console.cloud.google.com → créer/sélectionner un projet.
2. Activer **Maps JavaScript API**, **Places API**, **Directions API**, **Geocoding API**.
3. Credentials → **Create API key**, puis restreindre la clé par référent HTTP
   (votre domaine) pour éviter les abus.
4. Lier une carte bancaire (Google facture au-delà du crédit gratuit mensuel).

Tant que `firebaseConfig.apiKey` commence par `YOUR_`, l'app tourne en mode dégradé
(sans backend) au lieu de planter — pratique pour prévisualiser l'UI seule. Idem
côté carte : sans clé Google Maps valide, la carte reste vide mais le reste de
l'app fonctionne.

## 3. Configurer Stripe côté serveur
```bash
npm install -g firebase-tools
firebase login
firebase use --add            # sélectionner votre projet
firebase functions:secrets:set STRIPE_SECRET_KEY     # coller sk_live_... / sk_test_...
firebase functions:config:set stripe.webhook_secret="whsec_..."   # après l'étape 5
```

## 4. Déployer les règles, index et fonctions
```bash
cd functions && npm install && cd ..
firebase deploy --only firestore:rules,firestore:indexes,functions
```

## 5. Configurer le webhook Stripe
Dashboard Stripe → Developers → Webhooks → **Add endpoint** :
`https://REGION-PROJECT_ID.cloudfunctions.net/stripeWebhook`
Événement à écouter : `payment_intent.succeeded`. Copier le secret de signature
(`whsec_...`) et relancer la commande `functions:config:set` ci-dessus puis
redéployer les functions.

## 6. Peupler les données réelles (véhicules, chauffeurs, promos)
```bash
cd scripts
# Générer serviceAccountKey.json depuis Project settings > Comptes de service
node seed.js
```
Ce script écrit dans Firestore, pas dans du code en dur — vous pouvez ensuite gérer
vos chauffeurs/tarifs directement dans la console Firestore.

## 7. Déployer le site (hosting)
```bash
firebase deploy --only hosting
```

## 8. Publier sur les stores (PWA → app native)
L'app est une **PWA installable** (`manifest.json` + `service-worker.js` déjà en
place). Deux chemins standards, sans réécrire le code :

**Android (Play Store) — Trusted Web Activity**
```bash
npm install -g @bubblewrap/cli
bubblewrap init --manifest https://votre-domaine.com/manifest.json
bubblewrap build
```
Génère un `.aab` prêt à uploader sur Google Play Console.

**iOS (App Store) + Android alternative — PWABuilder**
1. https://www.pwabuilder.com → coller l'URL de votre site déployé.
2. Il audite le manifest/service worker puis génère un package Xcode (iOS) et/ou
   Android prêt à soumettre. Xcode reste nécessaire pour signer et soumettre à
   l'App Store (compte développeur Apple requis, 99 $/an).

Dans les deux cas, le contenu réel reste ce fichier `index.html` — les stores livrent
un wrapper natif qui pointe vers votre déploiement Firebase Hosting.

## Ce qui est réellement branché
- **Auth** : Firebase Auth (anonyme à l'arrivée, upgradable en e-mail/mot de passe, vrai
  écran de connexion/inscription).
- **Données** : véhicules, chauffeurs, historique, lieux enregistrés, moyens de
  paiement, codes promo → tous en Firestore temps réel (`onSnapshot`).
- **Dispatch** : Cloud Function `onRideCreated` assigne le chauffeur disponible le
  plus proche (Haversine réel sur les positions Firestore).
- **Position live + heatmap** : positions chauffeurs mises à jour en direct
  (Firestore `onSnapshot`), agrégées en zones de densité sur la carte.
- **Paiement** : PaymentIntent Stripe réel, Stripe Elements, webhook comme source de
  vérité, cartes enregistrées via SetupIntent.
- **Carte** : Google Maps JS API (rendu + styles dark/light), Places Autocomplete
  (suggestions d'adresse), Directions API (itinéraires), Geocoding API (adresse ↔
  coordonnées), géolocalisation navigateur réelle.
- **Chat in-app** : messages Firestore temps réel entre passager et chauffeur.
- **Annulation** de course réelle (libère le chauffeur côté serveur).
- **Surge pricing** : multiplicateur dynamique selon l'heure (heures de pointe,
  nuits de week-end), affiché et appliqué au prix facturé.
- **Price Lock 1h** : verrouille le prix affiché pendant 1h (persisté en localStorage).
- **Covoiturage (−40%)** et **mode Women-only** (filtre les chauffeurs certifiées,
  champ `womenOnly` sur les documents `drivers`).
- **Split fare** : diviseur ×2/×3/×4 + lien de partage (Web Share API ou presse-papiers).
- **SOS réel** : géolocalisation au moment de l'alerte, position poussée sur la
  course en cours, partage natif du lien de position.
- **Fidélité par paliers** (Bronze → Elite) avec % de cashback, calculée sur le
  nombre réel de courses terminées — plus de points fictifs.

## Ce qui reste à faire (hors périmètre de cette passe)
Dashboard chauffeur dédié, abonnements connectés, parrainage connecté, réservation
vocale, notifications push (FCM), module de livraison type "EAT", waiting fee facturé
automatiquement (actuellement non implémenté), matching covoiturage réel entre
passagers (le −40% s'applique pour l'instant sans matching effectif d'un second
passager).
