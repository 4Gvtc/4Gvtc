// scripts/seed.js — Run once to populate the real Firestore database.
// 1) In the Firebase Console: Project settings > Service accounts > Generate new private key.
// 2) Save it next to this file as serviceAccountKey.json (never commit it).
// 3) node scripts/seed.js

const admin = require('firebase-admin');
const path = require('path');

admin.initializeApp({
  credential: admin.credential.cert(require(path.join(__dirname, 'serviceAccountKey.json')))
});
const db = admin.firestore();

const vehicleTypes = [
  { id: 'moto', name: 'Moto', cat: 'Rapide', icon: '🏍️', cap: 1, eta: 1, price: 3.9, tagKey: 'fastest' },
  { id: 'eco', name: 'Éco', cat: 'Budget', icon: '🌿', cap: 4, eta: 5, price: 6.5, tagKey: 'cheapest' },
  { id: 'std', name: 'Standard', cat: 'Courant', icon: '🚗', cap: 4, eta: 3, price: 9.8, tagKey: null },
  { id: 'confort', name: 'Confort', cat: 'Courant', icon: '🚙', cap: 4, eta: 4, price: 13.5, tagKey: 'popular' },
  { id: 'elec', name: 'Électrique', cat: 'Éco', icon: '⚡', cap: 4, eta: 6, price: 10.9, tagKey: 'zeroCo2' },
  { id: 'xl', name: 'XL', cat: 'Groupe', icon: '🚐', cap: 6, eta: 7, price: 17.0, tagKey: null },
  { id: 'van', name: 'Van', cat: 'Groupe', icon: '🚌', cap: 8, eta: 10, price: 26.0, tagKey: null },
  { id: 'prem', name: 'Premium', cat: 'Premium', icon: '👑', cap: 4, eta: 6, price: 24.0, tagKey: 'business' },
  { id: 'luxe', name: 'Luxe', cat: 'Premium', icon: '💎', cap: 3, eta: 9, price: 42.0, tagKey: null },
  { id: 'taxi', name: 'Taxi', cat: 'Classique', icon: '🟡', cap: 4, eta: 2, price: 8.2, tagKey: null }
];

const drivers = [
  { id: 'drv_antoine', name: 'Antoine M.', rating: 4.97, trips: 3841, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop&auto=format', car: 'Tesla Model 3 · Noir · 33', plate: 'BX-241-CD', langs: ['Français', 'Anglais'], level: 'Elite Pro', status: 'available', phone: '+33600000001', womenOnly: false, location: { lat: 44.8378, lng: -0.5792 } },
  { id: 'drv_fatima', name: 'Fatima B.', rating: 4.94, trips: 2101, avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=80&h=80&fit=crop&auto=format', car: 'Peugeot 508 · Gris · 33', plate: 'BX-182-GH', langs: ['Français', 'Arabe'], level: 'Or', status: 'available', phone: '+33600000002', womenOnly: true, location: { lat: 44.8415, lng: -0.5703 } },
  { id: 'drv_pierre', name: 'Pierre L.', rating: 4.91, trips: 2974, avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop&auto=format', car: 'Mercedes EQS · Blanc · 33', plate: 'BX-305-KL', langs: ['Français', 'Espagnol'], level: 'Or', status: 'available', phone: '+33600000003', womenOnly: false, location: { lat: 44.8256, lng: -0.5561 } },
  { id: 'drv_sophie', name: 'Sophie N.', rating: 4.99, trips: 1654, avatar: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=40&h=40&fit=crop&auto=format', car: 'Renault Zoé · Bordeaux Rouge · 33', plate: 'BX-078-OP', langs: ['Français', 'Anglais'], level: 'Elite Pro', status: 'available', phone: '+33600000004', womenOnly: true, location: { lat: 44.8460, lng: -0.5380 } }
];

const promoCodes = [
  { id: 'RIDE20', discountEur: 2, active: true }
];

(async () => {
  for (const v of vehicleTypes) await db.collection('vehicleTypes').doc(v.id).set(v);
  for (const d of drivers) await db.collection('drivers').doc(d.id).set(d);
  for (const p of promoCodes) await db.collection('promoCodes').doc(p.id).set(p);
  console.log(`Seed terminé : ${vehicleTypes.length} véhicules, ${drivers.length} chauffeurs, ${promoCodes.length} codes promo.`);
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
