const functions = require('firebase-functions');
const admin = require('firebase-admin');
const Stripe = require('stripe');

admin.initializeApp();
const db = admin.firestore();

function stripeClient() {
  const key = functions.config().stripe?.secret || process.env.STRIPE_SECRET_KEY;
  if (!key) throw new functions.https.HttpsError('failed-precondition', 'STRIPE_SECRET_KEY non configurée (firebase functions:secrets:set STRIPE_SECRET_KEY)');
  return Stripe(key);
}

// 1) Create a real Stripe PaymentIntent for a ride fare.
exports.createPaymentIntent = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Connexion requise');
  const stripe = stripeClient();
  const amount = Math.round(Number(data.amount)); // cents
  if (!amount || amount < 50) throw new functions.https.HttpsError('invalid-argument', 'Montant invalide');
  const intent = await stripe.paymentIntents.create({
    amount, currency: 'eur',
    metadata: { uid: context.auth.uid, rideId: data.rideId || '' },
    automatic_payment_methods: { enabled: true }
  });
  if (data.rideId) {
    await db.collection('rides').doc(data.rideId).update({ stripePaymentIntentId: intent.id, paymentStatus: 'pending' });
  }
  return { clientSecret: intent.client_secret, paymentIntentId: intent.id };
});

// 2) Create a SetupIntent to save a card for later use (no charge).
exports.createSetupIntent = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Connexion requise');
  const stripe = stripeClient();
  const intent = await stripe.setupIntents.create({ metadata: { uid: context.auth.uid } });
  return { clientSecret: intent.client_secret };
});

// 3) Stripe webhook — confirms payment server-side (source of truth, not the client).
exports.stripeWebhook = functions.https.onRequest(async (req, res) => {
  const stripe = stripeClient();
  const sig = req.headers['stripe-signature'];
  const whSecret = functions.config().stripe?.webhook_secret;
  let event;
  try {
    event = whSecret ? stripe.webhooks.constructEvent(req.rawBody, sig, whSecret) : JSON.parse(req.rawBody);
  } catch (err) {
    console.error('Webhook signature error', err.message);
    res.status(400).send(`Webhook Error: ${err.message}`);
    return;
  }
  if (event.type === 'payment_intent.succeeded') {
    const pi = event.data.object;
    const rideId = pi.metadata?.rideId;
    if (rideId) await db.collection('rides').doc(rideId).update({ paymentStatus: 'paid' });
  }
  res.json({ received: true });
});

function distKm(a, b) {
  const R = 6371, toRad = d => d * Math.PI / 180;
  const dLat = toRad(b.lat - a.lat), dLng = toRad(b.lng - a.lng);
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

// 4) Real dispatch: pick the nearest available driver when a ride is created.
exports.onRideCreated = functions.firestore.document('rides/{rideId}').onCreate(async (snap) => {
  const ride = snap.data();
  if (!ride.fromCoords) return null;
  const driversSnap = await db.collection('drivers').where('status', '==', 'available').get();
  if (driversSnap.empty) return null;
  let best = null, bestDist = Infinity;
  driversSnap.forEach(d => {
    const drv = d.data();
    if (!drv.location) return;
    const dist = distKm(drv.location, ride.fromCoords);
    if (dist < bestDist) { bestDist = dist; best = { id: d.id, ...drv }; }
  });
  if (!best) return null;
  await new Promise(r => setTimeout(r, 2500)); // mirrors the dispatch UX delay
  await snap.ref.update({
    status: 'assigned', driverId: best.id,
    driverEtaMin: Math.max(1, Math.round(bestDist * 2.2)),
    assignedAt: admin.firestore.FieldValue.serverTimestamp()
  });
  await db.collection('drivers').doc(best.id).update({ status: 'on_ride' });
  return null;
});

// 5) Simulated live GPS feed — a real driver mobile app would replace this
//    with actual device geolocation writes; the Firestore pipe to clients is real either way.
exports.simulateDriverPositions = functions.pubsub.schedule('every 1 minutes').onRun(async () => {
  const snap = await db.collection('drivers').get();
  const batch = db.batch();
  snap.forEach(d => {
    const drv = d.data();
    if (!drv.location) return;
    const jitter = () => (Math.random() - 0.5) * 0.004;
    batch.update(d.ref, {
      location: { lat: drv.location.lat + jitter(), lng: drv.location.lng + jitter() },
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
  });
  await batch.commit();
  return null;
});

// 6) Free the driver + copy the ride into the rider's history once completed.
exports.onRideUpdated = functions.firestore.document('rides/{rideId}').onUpdate(async (change) => {
  const before = change.before.data(), after = change.after.data();
  if (before.status !== 'completed' && after.status === 'completed') {
    if (after.driverId) await db.collection('drivers').doc(after.driverId).update({ status: 'available' });
    let driverName = '', driverAvatar = '';
    if (after.driverId) {
      const drvDoc = await db.collection('drivers').doc(after.driverId).get();
      if (drvDoc.exists) { driverName = drvDoc.data().name || ''; driverAvatar = drvDoc.data().avatar || ''; }
    }
    await db.collection('users').doc(after.uid).collection('rides').doc(change.after.id).set({
      fromLabel: after.fromLabel, toLabel: after.toLabel, fare: after.fare,
      vehicleName: after.vehicleName, driverName, driverAvatar,
      rating: after.rating || 0, createdAt: after.createdAt
    });
  }
  // Rating submitted after the history doc was already copied — patch it in.
  if (before.rating !== after.rating && after.rating) {
    await db.collection('users').doc(after.uid).collection('rides').doc(change.after.id)
      .set({ rating: after.rating }, { merge: true }).catch(() => {});
  }
  // Free the driver immediately if the rider cancels.
  if (before.status !== 'cancelled' && after.status === 'cancelled' && after.driverId) {
    await db.collection('drivers').doc(after.driverId).update({ status: 'available' });
  }
  return null;
});

// 7) Real in-app chat — a driver mobile app would send its own messages the same way;
//    for now a short auto-reply simulates the driver side so the thread feels alive.
exports.onChatMessageCreated = functions.firestore
  .document('rides/{rideId}/messages/{messageId}')
  .onCreate(async (snap, ctx) => {
    const msg = snap.data();
    if (msg.senderRole !== 'rider') return null;
    const rideSnap = await db.collection('rides').doc(ctx.params.rideId).get();
    if (!rideSnap.exists) return null;
    const ride = rideSnap.data();
    if (!ride.driverId || ride.status === 'completed' || ride.status === 'cancelled') return null;
    await new Promise(r => setTimeout(r, 1800));
    const replies = ["J'arrive, encore quelques minutes 🚗", "Bien reçu, merci !", "Je suis juste devant.", "D'accord, à tout de suite."];
    await snap.ref.parent.add({
      text: replies[Math.floor(Math.random() * replies.length)],
      senderUid: ride.driverId, senderRole: 'driver',
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });
    return null;
  });
