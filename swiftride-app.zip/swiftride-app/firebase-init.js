// firebase-init.js — Real backend bridge (Firebase Auth + Firestore + Cloud Functions + Stripe).
// Fill in firebaseConfig and STRIPE_PUBLISHABLE_KEY below with your own project's values.
// See README_SETUP.md for the full setup walkthrough.

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
  getAuth, signInAnonymously, onAuthStateChanged,
  createUserWithEmailAndPassword, signInWithEmailAndPassword,
  linkWithCredential, EmailAuthProvider, signOut as fbSignOut,
  GoogleAuthProvider, OAuthProvider, signInWithPopup, linkWithPopup
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import {
  getFirestore, collection, doc, addDoc, getDoc, onSnapshot, query, orderBy,
  serverTimestamp, updateDoc
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getFunctions, httpsCallable } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-functions.js";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
const STRIPE_PUBLISHABLE_KEY = "pk_test_REPLACE_ME";

// If the config above hasn't been filled in, don't try to boot Firebase —
// let the app fall back to its offline/local mode instead of throwing.
const isConfigured = firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith("YOUR_");

let app, auth, db, functions, stripe, currentUser = null, authReadyResolve;
const authReady = new Promise(res => { authReadyResolve = res; });

if (isConfigured) {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  functions = getFunctions(app);
  stripe = window.Stripe ? window.Stripe(STRIPE_PUBLISHABLE_KEY) : null;

  onAuthStateChanged(auth, async (user) => {
    if (!user) { await signInAnonymously(auth).catch(e => console.error("Auth error", e)); return; }
    currentUser = user;
    authReadyResolve(user);
    window.dispatchEvent(new CustomEvent("fb:authchanged", { detail: { uid: user.uid, isAnonymous: user.isAnonymous } }));
  });
} else {
  console.warn("firebase-init.js: firebaseConfig is still a placeholder — the app will run without a live backend until you fill it in (see README_SETUP.md).");
}

async function upgradeAccount(email, password) {
  const cred = EmailAuthProvider.credential(email, password);
  return linkWithCredential(auth.currentUser, cred);
}
async function signIn(email, password) { return signInWithEmailAndPassword(auth, email, password); }
async function signUp(email, password) { return createUserWithEmailAndPassword(auth, email, password); }
async function signOut() { return fbSignOut(auth); }
async function signInWithProvider(providerName) {
  const provider = providerName === "google" ? new GoogleAuthProvider() : new OAuthProvider("apple.com");
  try {
    if (auth.currentUser && auth.currentUser.isAnonymous) {
      return await linkWithPopup(auth.currentUser, provider);
    }
    return await signInWithPopup(auth, provider);
  } catch (e) {
    // Anonymous account already tied to a different identity, or provider needs a fresh sign-in.
    if (e.code === "auth/credential-already-in-use" || e.code === "auth/email-already-in-use") {
      return await signInWithPopup(auth, provider);
    }
    throw e;
  }
}

function onVehicleTypes(cb) {
  return onSnapshot(collection(db, "vehicleTypes"), snap => cb(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
}
function onDrivers(cb) {
  return onSnapshot(collection(db, "drivers"), snap => cb(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
}
function onPromoCodes(cb) {
  return onSnapshot(collection(db, "promoCodes"), snap => cb(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
}
async function getDriver(driverId) {
  const snap = await getDoc(doc(db, "drivers", driverId));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}
async function onSavedPlaces(cb) {
  const user = await authReady;
  return onSnapshot(collection(db, "users", user.uid, "savedPlaces"), snap => cb(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
}
async function onPaymentMethods(cb) {
  const user = await authReady;
  return onSnapshot(collection(db, "users", user.uid, "paymentMethods"), snap => cb(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
}
async function onRideHistory(cb) {
  const user = await authReady;
  const q = query(collection(db, "users", user.uid, "rides"), orderBy("createdAt", "desc"));
  return onSnapshot(q, snap => cb(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
}

async function createRide(rideData) {
  const user = await authReady;
  const ref = await addDoc(collection(db, "rides"), { ...rideData, uid: user.uid, status: "requested", createdAt: serverTimestamp() });
  return ref.id;
}
function onRide(rideId, cb) {
  return onSnapshot(doc(db, "rides", rideId), snap => cb(snap.exists() ? { id: snap.id, ...snap.data() } : null));
}
async function updateRideStatus(rideId, status, extra = {}) {
  const payload = status === undefined ? { ...extra } : { status, ...extra };
  return updateDoc(doc(db, "rides", rideId), payload);
}

async function createPaymentIntent(amountEur, rideId) {
  const fn = httpsCallable(functions, "createPaymentIntent");
  const res = await fn({ amount: Math.round(amountEur * 100), rideId });
  return res.data; // { clientSecret, paymentIntentId }
}
async function createSetupIntent() {
  const fn = httpsCallable(functions, "createSetupIntent");
  const res = await fn({});
  return res.data; // { clientSecret }
}
async function confirmCardPayment(clientSecret, cardEl, billingName) {
  if (!stripe) throw new Error("Stripe.js n'est pas chargé");
  return stripe.confirmCardPayment(clientSecret, { payment_method: { card: cardEl, billing_details: { name: billingName || "" } } });
}
function mountCardElement(containerId) {
  if (!stripe) return null;
  const el = document.getElementById(containerId);
  if (!el) return null;
  el.innerHTML = "";
  const elements = stripe.elements();
  const style = { base: { color: "#ecedf6", fontFamily: "Outfit, sans-serif", fontSize: "15px", "::placeholder": { color: "#7878a0" } }, invalid: { color: "#f0405f" } };
  const card = elements.create("card", { style });
  card.mount("#" + containerId);
  return card;
}

async function sendRideMessage(rideId, text) {
  const user = await authReady;
  return addDoc(collection(db, "rides", rideId, "messages"), {
    text, senderUid: user.uid, senderRole: "rider", createdAt: serverTimestamp()
  });
}
function onRideMessages(rideId, cb) {
  const q = query(collection(db, "rides", rideId, "messages"), orderBy("createdAt", "asc"));
  return onSnapshot(q, snap => cb(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
}

async function savePaymentMethod(paymentMethodId, brand, last4) {
  const user = await authReady;
  return addDoc(collection(db, "users", user.uid, "paymentMethods"), { paymentMethodId, brand, last4, isDefault: false, createdAt: serverTimestamp() });
}
async function saveSavedPlace(place) {
  const user = await authReady;
  return addDoc(collection(db, "users", user.uid, "savedPlaces"), place);
}

if (isConfigured) {
  window.FB = {
    isConfigured, authReady, upgradeAccount, signIn, signUp, signOut, signInWithProvider,
    onVehicleTypes, onDrivers, onPromoCodes, getDriver, onSavedPlaces, onPaymentMethods, onRideHistory,
    createRide, onRide, updateRideStatus,
    createPaymentIntent, createSetupIntent, confirmCardPayment, mountCardElement,
    savePaymentMethod, saveSavedPlace, sendRideMessage, onRideMessages,
    get stripe() { return stripe; },
    get currentUser() { return currentUser; }
  };
  window.dispatchEvent(new CustomEvent("fb:ready"));
}
