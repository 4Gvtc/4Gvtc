import { lazy, Suspense } from "react"
import { AppHeader } from "./components/AppHeader"
import { StatePanel } from "./components/StatePanel"
import { AppStateProvider } from "./hooks/useAppState"
import { usePath } from "./hooks/usePath"
import { I18nProvider, useI18n } from "./i18n"

const HomePage = lazy(() => import("./features/booking/HomePage"))
const RolePage = lazy(() => import("./features/driver/RolePage"))
const DesignSystemPage = lazy(
  () => import("./features/design-system/DesignSystemPage"),
)

function Router() {
  const { path, navigate } = usePath()
  const { t } = useI18n()
  let page = <HomePage navigate={navigate} />
  if (path === "/driver") page = <RolePage role="driver" navigate={navigate} />
  if (path === "/admin") page = <RolePage role="admin" navigate={navigate} />
  if (path === "/design-system") page = <DesignSystemPage navigate={navigate} />
  return (
    <>
      <a className="skip-link" href="#main-content">
        {t("accessibility.skip")}
      </a>
      <AppHeader navigate={navigate} />
      <Suspense
        fallback={
          <div className="route-loading">
            <StatePanel kind="loading" titleKey="states.loadingTitle" />
          </div>
        }
      >
        {page}
      </Suspense>
    </>
  )
}

export default function App() {
  return (
    <I18nProvider>
      <AppStateProvider>
        <Router />
      </AppStateProvider>
    </I18nProvider>
  )
}
