import { mockDispatchService } from "./mockProvider"
export type { DispatchService } from "./interface"
export const dispatchService = mockDispatchService
