import { DRIVERS } from "../../data/drivers"
import { haversine } from "../../lib/geo"
import type { DispatchService } from "./interface"
export const mockDispatchService: DispatchService = {
  async assignDriver(ride, excludedDriverIds = []) {
    const origin = ride.stops[0]
    if (!origin) return null
    const available = DRIVERS.filter(
      (driver) =>
        driver.status === "available" &&
        !excludedDriverIds.includes(driver.id) &&
        (!ride.womenOnly || driver.womenOnly),
    )
    return (
      available.sort(
        (a, b) => haversine(origin, a.position) - haversine(origin, b.position),
      )[0] ?? null
    )
  },
}
