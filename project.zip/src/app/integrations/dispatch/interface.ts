import type { DriverProfile, Ride } from "../../types"
export interface DispatchService {
  assignDriver(
    ride: Ride,
    excludedDriverIds?: string[],
  ): Promise<DriverProfile | null>
}
