import type { Notification } from "../../types"
import type { NotificationService } from "./interface"
const notifications: Notification[] = []
const listeners = new Set<(notifications: Notification[]) => void>()
export const mockNotificationService: NotificationService = {
  async push(notification) {
    notifications.push(notification)
    listeners.forEach((listener) => listener(notifications))
    return notification
  },
  subscribe(callback) {
    listeners.add(callback)
    callback(notifications)
    return () => listeners.delete(callback)
  },
}
