import { mockNotificationService } from "./mockProvider"
export type { NotificationService } from "./interface"
export const notificationService = mockNotificationService
