import type { Notification } from "../../types"
export interface NotificationService {
  push(notification: Notification): Promise<Notification>
  subscribe(callback: (notifications: Notification[]) => void): () => void
}
