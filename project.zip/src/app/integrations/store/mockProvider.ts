import type { DataStore, Query, StoreListener, StoreTarget } from "./interface"

const STORAGE_KEY = "4g-vtc-store-v1"
type Database = Record<string, unknown>
interface BroadcastPayload {
  path: string
  database: Database
}
let database: Database = read()
const subscriptions = new Map<string, Set<StoreListener<unknown>>>()
const channel =
  typeof BroadcastChannel !== "undefined"
    ? new BroadcastChannel("4g-vtc-store")
    : null

function read(): Database {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "{}") as Database
  } catch {
    return {}
  }
}
function keyOf(target: StoreTarget) {
  return typeof target === "string" ? target : target.collection
}
function resolve<T>(target: StoreTarget): T {
  if (typeof target === "string") return database[target] as T
  const prefix = `${target.collection}/`
  const values = Object.entries(database)
    .filter(([key]) => key.startsWith(prefix))
    .map(([, value]) => value)
  return (
    target.where
      ? values.filter(
          (value) =>
            (value as Record<string, unknown>)[target.where!.field] ===
            target.where!.equals,
        )
      : values
  ) as T
}
function publish(target: StoreTarget) {
  const key = keyOf(target)
  subscriptions.get(key)?.forEach((listener) => listener(resolve(target)))
}
function persist(path: string) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(database))
  channel?.postMessage({ path, database })
  publish(path)
  publish(path.split("/")[0] ?? path)
}
channel?.addEventListener(
  "message",
  (event: MessageEvent<BroadcastPayload>) => {
    database = event.data.database
    publish(event.data.path)
    publish(event.data.path.split("/")[0] ?? event.data.path)
  },
)

export const mockStoreProvider: DataStore = {
  async get<T,>(path: string) {
    return database[path] as T | undefined ?? null
  },
  async list<T,>(query: Query) {
    return resolve<T[]>(query)
  },
  async create<T,>(path: string, value: T) {
    database[path] = value
    persist(path)
    return value
  },
  async update<T,>(path: string, value: Partial<T>) {
    const updated = { ...database[path] as object, ...value } as T
    database[path] = updated
    persist(path)
    return updated
  },
  async delete(path: string) {
    delete database[path]
    persist(path)
  },
  subscribe<T,>(target: StoreTarget, callback: StoreListener<T>) {
    const key = keyOf(target)
    const bucket = subscriptions.get(key) ?? new Set()
    bucket.add(callback as StoreListener<unknown>)
    subscriptions.set(key, bucket)
    callback(resolve(target))
    return () => bucket.delete(callback as StoreListener<unknown>)
  },
  async runTransaction<T,>(operation: () => Promise<T>) {
    return operation()
  },
  async reset() {
    database = {}
    localStorage.removeItem(STORAGE_KEY)
    channel?.postMessage({ path: "", database })
    subscriptions.forEach((_, key) => publish(key))
  },
}
