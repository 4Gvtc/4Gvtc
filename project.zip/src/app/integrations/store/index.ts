import { mockStoreProvider } from "./mockProvider"
export type { DataStore, Query } from "./interface"
export const dataStore = mockStoreProvider
