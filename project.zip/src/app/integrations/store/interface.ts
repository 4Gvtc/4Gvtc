interface QueryFilter {
  field: string
  equals: unknown
}

export interface Query {
  collection: string
  where?: QueryFilter
}
export type StoreTarget = string | Query
export type StoreListener<T> = (value: T) => void
export interface DataStore {
  get<T>(path: string): Promise<T | null>
  list<T>(query: Query): Promise<T[]>
  create<T>(path: string, value: T): Promise<T>
  update<T>(path: string, value: Partial<T>): Promise<T>
  delete(path: string): Promise<void>
  subscribe<T>(target: StoreTarget, callback: StoreListener<T>): () => void
  runTransaction<T>(operation: () => Promise<T>): Promise<T>
  reset(): Promise<void>
}
