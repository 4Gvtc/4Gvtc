import { afterEach, describe, expect, it, vi } from "vitest"
import { PLACES } from "../data/places"
import { haversine } from "../lib/geo"
import { mockGeocodingProvider } from "./geocoding/mockProvider"
import { mockRoutingProvider } from "./routing/mockProvider"

describe("offline provider fallbacks", () => {
  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it("uses the Bordeaux place catalogue when Nominatim fails", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new Error("offline")))
    const results = await mockGeocodingProvider.search("Gare")
    expect(results.map((place) => place.id)).toContain("saint-jean")
  })

  it("uses a weighted straight line when OSRM fails", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new Error("offline")))
    const points = [PLACES[0]!, PLACES[1]!]
    const result = await mockRoutingProvider.route(points)
    expect(result.distanceKm).toBeCloseTo(
      haversine(points[0], points[1]) * 1.35,
    )
    expect(result.durationMin).toBeCloseTo((result.distanceKm / 28) * 60)
    expect(result.geometry).toEqual(points)
  })
})
