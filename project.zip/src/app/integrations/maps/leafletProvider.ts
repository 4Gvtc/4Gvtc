import L, {
  type Circle,
  type Layer,
  type LayerGroup,
  type Map as LeafletMap,
  type TileLayer,
} from "leaflet"
import "leaflet/dist/leaflet.css"
import type { Coordinates } from "../../types"
import { connectivity } from "../connectivity"
import type {
  MapCallbacks,
  MapController,
  MapMarker,
  MapProvider,
  MapRenderState,
  MapRoute,
} from "./interface"

const TILE_URLS = {
  dark: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
  light: "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
} as const

class LeafletController implements MapController {
  private map: LeafletMap
  private tiles: TileLayer | null = null
  private markerLayer: LayerGroup
  private routeLayer: LayerGroup
  private state: MapRenderState
  private callbacks: MapCallbacks
  private renderedTheme: MapRenderState["theme"] | null = null
  private renderedBounds: L.LatLngBounds | null = null

  constructor(
    element: HTMLElement,
    state: MapRenderState,
    callbacks: MapCallbacks,
  ) {
    this.state = state
    this.callbacks = callbacks
    this.map = L.map(element, {
      center: [state.center.lat, state.center.lon],
      zoom: state.zoom,
      zoomControl: false,
      attributionControl: false,
      preferCanvas: true,
    })
    this.markerLayer = L.layerGroup().addTo(this.map)
    this.routeLayer = L.layerGroup().addTo(this.map)
    this.update(state)
  }

  update(state: MapRenderState) {
    this.state = state
    this.updateTiles()
    this.renderRoutes()
    this.renderMarkers()
    window.requestAnimationFrame(() => this.map.invalidateSize(false))
  }

  zoomIn() {
    this.map.zoomIn()
  }

  zoomOut() {
    this.map.zoomOut()
  }

  recenter(position: Coordinates, zoom = 15) {
    this.map.flyTo([position.lat, position.lon], zoom, { duration: 0.5 })
  }

  fitBounds() {
    if (!this.renderedBounds?.isValid()) return
    this.map.fitBounds(this.renderedBounds, {
      paddingTopLeft: [20, 20],
      paddingBottomRight: [20, this.state.bottomPadding],
      maxZoom: 16,
      animate: true,
    })
  }

  destroy() {
    this.map.remove()
  }

  private updateTiles() {
    if (this.renderedTheme === this.state.theme) return
    if (this.tiles) this.map.removeLayer(this.tiles)
    const layer = L.tileLayer(TILE_URLS[this.state.theme], {
      subdomains: "abcd",
      maxZoom: 20,
      detectRetina: true,
    })
    let loaded = false
    layer.on("tileload", () => {
      if (loaded) return
      loaded = true
      connectivity.reportSuccess("tiles")
    })
    layer.on("tileerror", () => connectivity.reportFailure("tiles"))
    layer.addTo(this.map)
    this.tiles = layer
    this.renderedTheme = this.state.theme
  }

  private renderRoutes() {
    this.routeLayer.clearLayers()
    const bounds = L.latLngBounds([])
    const ordered = [...this.state.routes].sort(
      (a, b) => Number(a.selected) - Number(b.selected),
    )
    ordered.forEach((route) => {
      if (!route.points.length) return
      const points = route.points.map(
        (point) => [point.lat, point.lon] as L.LatLngTuple,
      )
      points.forEach((point) => bounds.extend(point))
      if (route.selected) {
        L.polyline(points, {
          color: "#2563eb",
          weight: 11,
          opacity: 0.2,
          interactive: false,
          lineCap: "round",
          lineJoin: "round",
        }).addTo(this.routeLayer)
        L.polyline(points, {
          color: "#2563eb",
          weight: 5,
          opacity: 1,
          interactive: false,
          lineCap: "round",
          lineJoin: "round",
        }).addTo(this.routeLayer)
      } else {
        const alternative = L.polyline(points, {
          color: this.state.theme === "dark" ? "#8c8cb4" : "#55557f",
          weight: 5,
          opacity: 0.58,
          interactive: true,
          lineCap: "round",
          dashArray: "8 9",
        }).addTo(this.routeLayer)
        alternative.on("click", () =>
          this.callbacks.onAlternativeSelect(route.id),
        )
      }
    })
    this.renderedBounds = bounds.isValid() ? bounds : null
  }

  private renderMarkers() {
    this.markerLayer.clearLayers()
    const bounds = this.renderedBounds ?? L.latLngBounds([])
    this.state.markers.forEach((marker) => {
      bounds.extend([marker.position.lat, marker.position.lon])
      const icon = L.divIcon({
        className: "leaflet-marker-shell",
        html: markerHtml(marker),
        iconSize: marker.kind === "driver" ? [48, 48] : [38, 38],
        iconAnchor: marker.kind === "driver" ? [24, 24] : [19, 19],
      })
      L.marker([marker.position.lat, marker.position.lon], {
        icon,
        keyboard: false,
        title: marker.label,
        interactive: false,
      }).addTo(this.markerLayer)
      if (
        marker.kind === "user" &&
        marker.accuracyMeters &&
        marker.accuracyMeters > 0
      ) {
        const circle: Circle = L.circle(
          [marker.position.lat, marker.position.lon],
          {
            radius: marker.accuracyMeters,
            color: "#2563eb",
            fillColor: "#2563eb",
            fillOpacity: 0.08,
            opacity: 0.28,
            weight: 1,
            interactive: false,
          },
        )
        circle.addTo(this.markerLayer)
      }
    })
    this.renderedBounds = bounds.isValid() ? bounds : null
  }
}

function markerHtml(marker: MapMarker) {
  if (marker.kind === "driver") {
    const heading = Number.isFinite(marker.heading) ? marker.heading : 0
    return `<span class="leaflet-driver-marker" style="--driver-heading:${heading}deg"><svg viewBox="0 0 48 48" aria-hidden="true"><path d="M24 5 31 17 40 23 35 38 24 43 13 38 8 23 17 17 24 5Z"/><path d="M17 24h14M18 31h12" fill="none"/></svg></span>`
  }
  if (marker.kind === "stop") {
    return `<span class="leaflet-map-marker leaflet-map-marker--stop">${marker.index ?? ""}</span>`
  }
  return `<span class="leaflet-map-marker leaflet-map-marker--${marker.kind}"><span></span></span>`
}

export const leafletMapProvider: MapProvider = {
  mount(element, state, callbacks) {
    return new LeafletController(element, state, callbacks)
  },
}
