import type {
  MapCallbacks,
  MapController,
  MapProvider,
  MapRenderState,
} from "./interface"

class MockMapController implements MapController {
  constructor(public state: MapRenderState) {}
  update(state: MapRenderState) {
    this.state = state
  }
  zoomIn() {}
  zoomOut() {}
  recenter() {}
  fitBounds() {}
  destroy() {}
}

export const mockMapProvider: MapProvider = {
  mount(
    _element: HTMLElement,
    state: MapRenderState,
    _callbacks: MapCallbacks,
  ) {
    return new MockMapController(state)
  },
}
