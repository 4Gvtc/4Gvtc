import type { Coordinates, Theme } from "../../types"

export type MapMarkerKind = "origin" | "destination" | "stop" | "driver" | "user"

export interface MapMarker {
  id: string
  position: Coordinates
  kind: MapMarkerKind
  label?: string
  index?: number
  heading?: number
  accuracyMeters?: number
}

export interface MapRoute {
  id: string
  points: Coordinates[]
  selected: boolean
  alternative: boolean
}

export interface MapRenderState {
  theme: Theme
  center: Coordinates
  zoom: number
  markers: MapMarker[]
  routes: MapRoute[]
  bottomPadding: number
}

export interface MapCallbacks {
  onAlternativeSelect: (routeId: string) => void
}

export interface MapController {
  update(state: MapRenderState): void
  zoomIn(): void
  zoomOut(): void
  recenter(position: Coordinates, zoom?: number): void
  fitBounds(): void
  destroy(): void
}

export interface MapProvider {
  mount(
    element: HTMLElement,
    state: MapRenderState,
    callbacks: MapCallbacks,
  ): MapController
}
