export type ConnectivitySource = "network" | "tiles" | "geocoding" | "routing"

type Listener = (offline: boolean) => void

const failures = new Set<ConnectivitySource>()
const listeners = new Set<Listener>()

function notify() {
  const offline = failures.size > 0
  listeners.forEach((listener) => listener(offline))
}

export const connectivity = {
  reportFailure(source: ConnectivitySource) {
    failures.add(source)
    notify()
  },
  reportSuccess(source: ConnectivitySource) {
    failures.delete(source)
    notify()
  },
  subscribe(listener: Listener) {
    listeners.add(listener)
    listener(failures.size > 0)
    return () => {
      listeners.delete(listener)
    }
  },
  isOffline() {
    return failures.size > 0
  },
}

if (typeof window !== "undefined") {
  if (!navigator.onLine) failures.add("network")
  window.addEventListener("offline", () =>
    connectivity.reportFailure("network"),
  )
  window.addEventListener("online", () => connectivity.reportSuccess("network"))
}
