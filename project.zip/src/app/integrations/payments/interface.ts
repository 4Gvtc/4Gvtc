import type { PaymentMethod } from "../../types"
export interface PaymentProvider {
  listMethods(): Promise<PaymentMethod[]>
  addMethod(method: PaymentMethod): Promise<PaymentMethod>
  removeMethod(id: string): Promise<void>
  setDefault(id: string): Promise<void>
  charge(amount: number, rideId: string): Promise<{
    id: string
    status: "simulated"
    amount: number
    rideId: string
  }>
}
