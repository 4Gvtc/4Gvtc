import { mockPaymentProvider } from "./mockProvider"
export type { PaymentProvider } from "./interface"
export const paymentProvider = mockPaymentProvider
