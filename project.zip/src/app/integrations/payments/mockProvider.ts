import type { PaymentMethod } from "../../types"
import type { PaymentProvider } from "./interface"
let methods: PaymentMethod[] = [{ id: "cash", type: "cash", isDefault: true }]
export const mockPaymentProvider: PaymentProvider = {
  async listMethods() {
    return methods
  },
  async addMethod(method) {
    methods = [...methods, method]
    return method
  },
  async removeMethod(id) {
    methods = methods.filter((method) => method.id !== id)
  },
  async setDefault(id) {
    methods = methods.map((method) => ({
      ...method,
      isDefault: method.id === id,
    }))
  },
  async charge(amount, rideId) {
    return { id: crypto.randomUUID(), status: "simulated", amount, rideId }
  },
}
