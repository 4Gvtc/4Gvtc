import { mockGeocodingProvider } from "./mockProvider"
import type { Coordinates } from "../../types"
export type { GeocodingProvider } from "./interface"
let lastRequest = 0
export const geocodingProvider = {
  async search(query: string, bias?: Coordinates) {
    const wait = Math.max(450, 1000 - (Date.now() - lastRequest))
    await new Promise((resolve) => window.setTimeout(resolve, wait))
    lastRequest = Date.now()
    return mockGeocodingProvider.search(query, bias)
  },
  reverse: mockGeocodingProvider.reverse,
}
