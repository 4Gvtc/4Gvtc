import type { Coordinates, Place } from "../../types"
export interface GeocodingProvider {
  search(query: string, bias?: Coordinates): Promise<Place[]>
  reverse(lat: number, lon: number): Promise<Place | null>
}
