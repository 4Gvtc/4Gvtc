import { PLACES } from "../../data/places"
import { haversine } from "../../lib/geo"
import { connectivity } from "../connectivity"
import type { GeocodingProvider } from "./interface"
const localSearch = (query: string) =>
  PLACES.filter((place) =>
    `${place.name} ${place.address}`
      .toLocaleLowerCase()
      .includes(query.toLocaleLowerCase()),
  )
export const mockGeocodingProvider: GeocodingProvider = {
  async search(query) {
    if (!query.trim()) return []
    try {
      const url = new URL("https://nominatim.openstreetmap.org/search")
      url.search = new URLSearchParams({
        q: `${query}, Bordeaux`,
        format: "json",
        limit: "5",
      }).toString()
      const response = await fetch(url, {
        headers: { "Accept-Language": "fr" },
        signal: AbortSignal.timeout(1800),
      })
      if (!response.ok) throw new Error("geocoding unavailable")
      const rows = (await response.json()) as Array<{
        place_id: number
        display_name: string
        lat: string
        lon: string
      }>
      connectivity.reportSuccess("geocoding")
      return rows.map((row) => ({
        id: String(row.place_id),
        name: row.display_name.split(",")[0] ?? row.display_name,
        address: row.display_name,
        lat: Number(row.lat),
        lon: Number(row.lon),
      }))
    } catch {
      connectivity.reportFailure("geocoding")
      return localSearch(query)
    }
  },
  async reverse(lat, lon) {
    return (
      [...PLACES].sort(
        (a, b) => haversine({ lat, lon }, a) - haversine({ lat, lon }, b),
      )[0] ?? null
    )
  },
}
