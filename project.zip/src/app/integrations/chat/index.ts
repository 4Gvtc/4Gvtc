import { mockChatService } from "./mockProvider"
export type { ChatService } from "./interface"
export const chatService = mockChatService
