import type { ChatMessage } from "../../types"
export interface ChatService {
  sendMessage(message: ChatMessage): Promise<ChatMessage>
  subscribe(
    rideId: string,
    callback: (messages: ChatMessage[]) => void,
  ): () => void
}
