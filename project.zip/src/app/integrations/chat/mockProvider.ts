import type { ChatMessage } from "../../types"
import type { ChatService } from "./interface"
const messages: ChatMessage[] = []
const listeners = new Map<string, Set<(messages: ChatMessage[]) => void>>()
export const mockChatService: ChatService = {
  async sendMessage(message) {
    messages.push(message)
    listeners
      .get(message.rideId)
      ?.forEach((listener) =>
        listener(messages.filter((item) => item.rideId === message.rideId)),
      )
    return message
  },
  subscribe(rideId, callback) {
    const bucket = listeners.get(rideId) ?? new Set()
    bucket.add(callback)
    listeners.set(rideId, bucket)
    callback(messages.filter((message) => message.rideId === rideId))
    return () => bucket.delete(callback)
  },
}
