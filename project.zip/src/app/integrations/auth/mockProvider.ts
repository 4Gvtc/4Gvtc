import type { AuthProvider, AuthListener } from "./interface"
import type { User } from "../../types"
let current: User | null = null
const listeners = new Set<AuthListener>()
const notify = () => listeners.forEach((listener) => listener(current))
const makeUser = (): User => ({
  id: crypto.randomUUID(),
  role: "rider",
  createdAt: new Date().toISOString(),
})
export const mockAuthProvider: AuthProvider = {
  async signUp() {
    current = makeUser()
    notify()
    return current
  },
  async signIn() {
    current = makeUser()
    notify()
    return current
  },
  async signInAnonymously() {
    current = makeUser()
    notify()
    return current
  },
  async signInWithProvider() {
    current = makeUser()
    notify()
    return current
  },
  async signOut() {
    current = null
    notify()
  },
  onAuthChange(listener) {
    listeners.add(listener)
    listener(current)
    return () => listeners.delete(listener)
  },
  async deleteAccount() {
    current = null
    notify()
  },
}
