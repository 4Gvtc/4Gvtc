import { mockAuthProvider } from "./mockProvider"
export type { AuthProvider } from "./interface"
export const authProvider = mockAuthProvider
