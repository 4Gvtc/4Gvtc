import type { User } from "../../types"
export type AuthListener = (user: User | null) => void
export interface AuthProvider {
  signUp(): Promise<User>
  signIn(): Promise<User>
  signInAnonymously(): Promise<User>
  signInWithProvider(provider: "google" | "apple"): Promise<User>
  signOut(): Promise<void>
  onAuthChange(listener: AuthListener): () => void
  deleteAccount(): Promise<void>
}
