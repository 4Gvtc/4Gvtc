import { haversine } from "../../lib/geo"
import type { Coordinates } from "../../types"
import { connectivity } from "../connectivity"
import type { RoutingProvider, RouteResult } from "./interface"
function fallback(points: Coordinates[]): RouteResult {
  const straight = points
    .slice(1)
    .reduce((sum, point, index) => sum + haversine(points[index]!, point), 0)
  const distanceKm = straight * 1.35
  const durationMin = (distanceKm / 28) * 60
  return {
    distanceKm,
    durationMin,
    geometry: points,
    alternatives: [
      {
        distanceKm: distanceKm * 1.08,
        durationMin: durationMin * 0.94,
        geometry: points,
      },
    ],
  }
}
export const mockRoutingProvider: RoutingProvider = {
  async route(points) {
    if (points.length < 2) return fallback(points)
    try {
      const coordinates = points
        .map((point) => `${point.lon},${point.lat}`)
        .join(";")
      const response = await fetch(
        `https://router.project-osrm.org/route/v1/driving/${coordinates}?overview=full&geometries=geojson&alternatives=true`,
        { signal: AbortSignal.timeout(2200) },
      )
      if (!response.ok) throw new Error("routing unavailable")
      const data = (await response.json()) as {
        routes: Array<{
          distance: number
          duration: number
          geometry: { coordinates: [number, number][] }
        }>
      }
      const [main, ...alternatives] = data.routes
      if (!main) {
        connectivity.reportFailure("routing")
        return fallback(points)
      }
      const convert = (route: typeof main) => ({
        distanceKm: route.distance / 1000,
        durationMin: route.duration / 60,
        geometry: route.geometry.coordinates.map(([lon, lat]) => ({
          lat,
          lon,
        })),
      })
      connectivity.reportSuccess("routing")
      return { ...convert(main), alternatives: alternatives.map(convert) }
    } catch {
      connectivity.reportFailure("routing")
      return fallback(points)
    }
  },
}
