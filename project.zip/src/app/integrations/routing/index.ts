import { mockRoutingProvider } from "./mockProvider"
export type { RoutingProvider, RouteResult } from "./interface"
export const routingProvider = mockRoutingProvider
