import type { Coordinates } from "../../types"
export interface RouteResult {
  distanceKm: number
  durationMin: number
  geometry: Coordinates[]
  alternatives: Array<{
    distanceKm: number
    durationMin: number
    geometry: Coordinates[]
  }>
}
export interface RoutingProvider {
  route(points: Coordinates[]): Promise<RouteResult>
}
