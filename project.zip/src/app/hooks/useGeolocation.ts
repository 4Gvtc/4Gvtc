import { useState } from "react"
import type { Coordinates } from "../types"
export function useGeolocation() {
  const [position, setPosition] = useState<Coordinates | null>(null)
  const [error, setError] = useState<GeolocationPositionError | null>(null)
  const request = () =>
    navigator.geolocation.getCurrentPosition(
      ({ coords }) =>
        setPosition({ lat: coords.latitude, lon: coords.longitude }),
      setError,
    )
  return { position, error, request }
}
