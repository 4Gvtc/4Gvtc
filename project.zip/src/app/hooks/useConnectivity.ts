import { useEffect, useState } from "react"
import { connectivity } from "../integrations/connectivity"

export function useConnectivity() {
  const [offline, setOffline] = useState(connectivity.isOffline())
  useEffect(() => connectivity.subscribe(setOffline), [])
  return offline
}
