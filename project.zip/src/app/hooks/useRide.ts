import { useMemo } from "react"
import type { Ride } from "../types"
export function useRide(rides: Ride[], id?: string) {
  return useMemo(
    () => rides.find((ride) => ride.id === id) ?? null,
    [id, rides],
  )
}
