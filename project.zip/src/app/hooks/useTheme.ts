import { useEffect, useState } from "react"
import type { Theme } from "../types"

function initialTheme(): Theme {
  const saved = localStorage.getItem("4g-vtc-theme") as Theme | null
  if (saved === "dark" || saved === "light") return saved
  return matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
}

export function useTheme() {
  const [theme, setTheme] = useState<Theme>(initialTheme)
  useEffect(() => {
    const syncTheme = (event: Event) => {
      const nextTheme = (event as CustomEvent<Theme>).detail
      if (nextTheme === "dark" || nextTheme === "light") {
        setTheme(nextTheme)
      }
    }
    window.addEventListener("4g-vtc-theme", syncTheme)
    return () => window.removeEventListener("4g-vtc-theme", syncTheme)
  }, [])
  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark")
    document.documentElement.style.colorScheme = theme
    localStorage.setItem("4g-vtc-theme", theme)
    window.dispatchEvent(
      new CustomEvent<Theme>("4g-vtc-theme", {
        detail: theme,
      }),
    )
  }, [theme])
  return {
    theme,
    setTheme,
    toggleTheme: () =>
      setTheme((value) => (value === "dark" ? "light" : "dark")),
  }
}
