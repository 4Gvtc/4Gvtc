import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react"
import { DRIVERS } from "../data/drivers"
import { dataStore } from "../integrations/store"
import type { AppState, Coordinates, Ride, Role } from "../types"

const ROUTE: Coordinates[] = [
  { lat: 44.826, lon: -0.556 },
  { lat: 44.832, lon: -0.563 },
  { lat: 44.838, lon: -0.571 },
  { lat: 44.844, lon: -0.576 },
  { lat: 44.851, lon: -0.57 },
  { lat: 44.858, lon: -0.558 },
  { lat: 44.862, lon: -0.55 },
  { lat: 44.854, lon: -0.565 },
  { lat: 44.844, lon: -0.584 },
  { lat: 44.836, lon: -0.587 },
  { lat: 44.829, lon: -0.578 },
]

const initialState: AppState = {
  role: "rider",
  speed: 1,
  rides: [],
  notifications: [],
  paymentMethods: [],
  savedPlaces: [],
  driverPositions: Object.fromEntries(
    DRIVERS.map((driver) => [driver.id, driver.position]),
  ),
  driverStatuses: Object.fromEntries(
    DRIVERS.map((driver) => [driver.id, driver.status]),
  ),
  usedPromoCodes: [],
}

interface AppStateValue {
  state: AppState
  setRole: (role: Role) => void
  setSpeed: (speed: 1 | 5 | 10) => void
  reset: () => Promise<void>
  saveRide: (ride: Ride) => void
  markPromoUsed: (code: string) => void
  setDriverStatus: (
    driverId: string,
    status: "offline" | "available" | "on_ride",
  ) => void
}

const AppStateContext = createContext<AppStateValue | null>(null)

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState(initialState)
  const routeStep = useRef(0)
  const activeRideId = useRef<string | null>(null)
  const activeRouteStep = useRef(0)

  useEffect(
    () =>
      dataStore.subscribe<AppState>("settings/app", (stored) => {
        if (stored) setState({ ...initialState, ...stored })
      }),
    [],
  )

  useEffect(() => {
    const delay = Math.max(140, 1400 / state.speed)
    const timer = window.setInterval(() => {
      routeStep.current = (routeStep.current + 1) % ROUTE.length
      setState((current) => {
        const activeRide = current.rides.find(
          (ride) =>
            (ride.status === "driver_assigned" ||
              ride.status === "in_progress") &&
            ride.driverId &&
            ride.route?.length,
        )
        if (activeRide?.id !== activeRideId.current) {
          activeRideId.current = activeRide?.id ?? null
          activeRouteStep.current = 0
        }
        if (activeRide?.route?.length) {
          const increment = Math.max(
            1,
            Math.floor(activeRide.route.length / 80),
          )
          activeRouteStep.current = Math.min(
            activeRide.route.length - 1,
            activeRouteStep.current + increment,
          )
        }
        const positions = Object.fromEntries(
          DRIVERS.map((driver, index) => {
            const activePoint =
              activeRide?.driverId === driver.id
                ? activeRide.route?.[activeRouteStep.current]
                : undefined
            const base =
              activePoint ??
              ROUTE[(routeStep.current + index * 2) % ROUTE.length]!
            const noise = Math.sin(routeStep.current + index) * 0.00008
            return [driver.id, { lat: base.lat + noise, lon: base.lon - noise }]
          }),
        )
        const next = { ...current, driverPositions: positions }
        void dataStore.create("settings/app", next)
        return next
      })
    }, delay)
    return () => window.clearInterval(timer)
  }, [state.speed])

  const value = useMemo<AppStateValue>(
    () => ({
      state,
      setRole: (role) =>
        setState((current) => {
          const next = { ...current, role }
          void dataStore.create("settings/app", next)
          return next
        }),
      setSpeed: (speed) =>
        setState((current) => {
          const next = { ...current, speed }
          void dataStore.create("settings/app", next)
          return next
        }),
      saveRide: (ride) =>
        setState((current) => {
          const rides = current.rides.some((item) => item.id === ride.id)
            ? current.rides.map((item) => (item.id === ride.id ? ride : item))
            : [...current.rides, ride]
          const next = { ...current, rides }
          void dataStore.create("settings/app", next)
          return next
        }),
      markPromoUsed: (code) =>
        setState((current) => {
          if (current.usedPromoCodes.includes(code)) return current
          const next = {
            ...current,
            usedPromoCodes: [...current.usedPromoCodes, code],
          }
          void dataStore.create("settings/app", next)
          return next
        }),
      setDriverStatus: (driverId, status) =>
        setState((current) => {
          const next = {
            ...current,
            driverStatuses: {
              ...current.driverStatuses,
              [driverId]: status,
            },
          }
          void dataStore.create("settings/app", next)
          return next
        }),
      reset: async () => {
        await dataStore.reset()
        routeStep.current = 0
        setState(initialState)
        await dataStore.create("settings/app", initialState)
      },
    }),
    [state],
  )

  return (
    <AppStateContext.Provider value={value}>
      {children}
    </AppStateContext.Provider>
  )
}

export function useAppState() {
  const value = useContext(AppStateContext)
  if (!value) throw new Error("AppStateProvider is missing")
  return value
}
