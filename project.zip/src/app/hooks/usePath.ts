import { useEffect, useState } from "react"

export function usePath() {
  const [path, setPathState] = useState(window.location.pathname)
  useEffect(() => {
    const update = () => setPathState(window.location.pathname)
    window.addEventListener("popstate", update)
    return () => window.removeEventListener("popstate", update)
  }, [])
  const navigate = (next: string) => {
    if (next === window.location.pathname) return
    history.pushState({}, "", next)
    setPathState(next)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }
  return { path, navigate }
}
