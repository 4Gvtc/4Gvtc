import { useEffect, useState } from "react"
export function useCountdown(target: Date) {
  const [remaining, setRemaining] = useState(() =>
    Math.max(0, target.getTime() - Date.now()),
  )
  useEffect(() => {
    const timer = window.setInterval(
      () => setRemaining(Math.max(0, target.getTime() - Date.now())),
      1000,
    )
    return () => window.clearInterval(timer)
  }, [target])
  return remaining
}
