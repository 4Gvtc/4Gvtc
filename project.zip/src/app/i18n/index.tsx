import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react"
import ar from "./ar.json"
import de from "./de.json"
import en from "./en.json"
import es from "./es.json"
import fr from "./fr.json"
import type { Locale } from "../types"

const messages = { fr, en, de, es, ar } as const
export type TranslationKey = keyof typeof fr

interface I18nValue {
  locale: Locale
  setLocale: (locale: Locale) => void
  t: (key: TranslationKey, values?: Record<string, string | number>) => string
}

const I18nContext = createContext<I18nValue | null>(null)

function detectLocale(): Locale {
  const saved = localStorage.getItem("4g-vtc-locale") as Locale | null
  if (saved && saved in messages) return saved
  const browser = navigator.language.slice(0, 2) as Locale
  return browser in messages ? browser : "fr"
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(detectLocale)

  useEffect(() => {
    document.documentElement.lang = locale
    document.documentElement.dir = locale === "ar" ? "rtl" : "ltr"
    localStorage.setItem("4g-vtc-locale", locale)
  }, [locale])

  const value = useMemo<I18nValue>(
    () => ({
      locale,
      setLocale: setLocaleState,
      t: (key, values) => {
        const template = messages[locale][key] ?? messages.fr[key]
        return Object.entries(values ?? {}).reduce(
          (text, [name, value]) => text.split(`{${name}}`).join(String(value)),
          template,
        )
      },
    }),
    [locale],
  )

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>
}

export function useI18n() {
  const value = useContext(I18nContext)
  if (!value) throw new Error("I18nProvider is missing")
  return value
}
