import { describe, expect, it } from "vitest"
import ar from "./ar.json"
import de from "./de.json"
import en from "./en.json"
import es from "./es.json"
import fr from "./fr.json"

describe("translation dictionaries", () => {
  it.each([en, de, es, ar])(
    "has exactly the French reference keys",
    (dictionary) => {
      expect(Object.keys(dictionary).sort()).toEqual(Object.keys(fr).sort())
    },
  )
})
