import type { PromoCode } from "../types"
export const PROMOS: PromoCode[] = [
  { code: "RIDE20", amountOff: 2, maxUses: 1 },
]
