export const TARIFFS = {
  base: 2,
  perKm: 0.95,
  perMinute: 0.22,
  minimum: 6,
  extraStop: 1,
  carpoolDiscount: 0.4,
  freeWaitingMinutes: 3,
  waitingPerMinute: 0.3,
  freeCancellationMinutes: 2,
  cancellationFee: 3,
  priceLockMinutes: 60,
} as const

export function surgeFor(date: Date): number {
  const day = date.getDay()
  const hour = date.getHours()
  const weekdayPeak =
    day >= 1 &&
    day <= 5 &&
    ((hour >= 7 && hour < 9) || (hour >= 17 && hour < 19))
  const weekendNight = (day === 5 || day === 6) && (hour >= 22 || hour < 3)
  if (weekendNight) return 1.5
  if (weekdayPeak) return 1.3
  return 1
}
