import type { LoyaltyTier } from "../types"
export const LOYALTY_TIERS: LoyaltyTier[] = [
  { id: "bronze", ridesRequired: 0, cashbackPercent: 0 },
  { id: "silver", ridesRequired: 10, cashbackPercent: 1 },
  { id: "gold", ridesRequired: 30, cashbackPercent: 2 },
  { id: "platinum", ridesRequired: 75, cashbackPercent: 3 },
  { id: "elite", ridesRequired: 150, cashbackPercent: 5 },
]
