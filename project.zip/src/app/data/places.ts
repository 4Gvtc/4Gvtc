import type { Place } from "../types"

export const BORDEAUX_CENTER = { lat: 44.8378, lon: -0.5792 }
export const PLACES: Place[] = [
  {
    id: "bourse",
    name: "Place de la Bourse",
    address: "Place de la Bourse, Bordeaux",
    lat: 44.8415,
    lon: -0.5701,
  },
  {
    id: "saint-jean",
    name: "Gare Saint-Jean",
    address: "Rue Charles Domercq, Bordeaux",
    lat: 44.8259,
    lon: -0.5562,
  },
  {
    id: "vin",
    name: "Cité du Vin",
    address: "Esplanade de Pontac, Bordeaux",
    lat: 44.8622,
    lon: -0.5501,
  },
  {
    id: "airport",
    name: "Aéroport de Bordeaux-Mérignac",
    address: "Mérignac",
    lat: 44.8283,
    lon: -0.7156,
  },
  {
    id: "intendance",
    name: "Cours de l’Intendance",
    address: "Cours de l’Intendance, Bordeaux",
    lat: 44.8426,
    lon: -0.577,
  },
  {
    id: "cloche",
    name: "Grosse Cloche",
    address: "Rue Saint-James, Bordeaux",
    lat: 44.8352,
    lon: -0.5715,
  },
  {
    id: "meriadeck",
    name: "Mériadeck",
    address: "Quartier Mériadeck, Bordeaux",
    lat: 44.8389,
    lon: -0.5864,
  },
  {
    id: "chartrons",
    name: "Chartrons",
    address: "Quai des Chartrons, Bordeaux",
    lat: 44.8543,
    lon: -0.5682,
  },
  {
    id: "gambetta",
    name: "Place Gambetta",
    address: "Place Gambetta, Bordeaux",
    lat: 44.8416,
    lon: -0.5828,
  },
  {
    id: "darwin",
    name: "Darwin",
    address: "Quai des Queyries, Bordeaux",
    lat: 44.849,
    lon: -0.5593,
  },
]
