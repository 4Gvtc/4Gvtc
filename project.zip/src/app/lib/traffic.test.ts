import { describe, expect, it } from "vitest"
import { trafficEstimate } from "./traffic"

describe("trafficEstimate", () => {
  it("marks weekday rush hour as busy", () => {
    expect(trafficEstimate(new Date("2026-07-20T08:00:00")).period).toBe("busy")
  })

  it("uses a higher average speed at night", () => {
    expect(
      trafficEstimate(new Date("2026-07-20T23:00:00")).averageSpeedKmh,
    ).toBeGreaterThan(28)
  })
})
