import type { Locale } from "../types"

export const localeTags: Record<Locale, string> = {
  fr: "fr-FR",
  en: "en-GB",
  de: "de-DE",
  es: "es-ES",
  ar: "ar-u-nu-latn",
}

export function formatMoney(value: number, locale: Locale) {
  return new Intl.NumberFormat(localeTags[locale], {
    style: "currency",
    currency: "EUR",
  }).format(value)
}

export function formatDistance(value: number, locale: Locale) {
  return new Intl.NumberFormat(localeTags[locale], {
    style: "unit",
    unit: "kilometer",
    maximumFractionDigits: 1,
  }).format(value)
}
