export const createId = (prefix = "id") => `${prefix}_${crypto.randomUUID()}`
