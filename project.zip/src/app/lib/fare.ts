import { TARIFFS } from "../data/tariffs"
import type { FareBreakdown } from "../types"

interface FareInput {
  distanceKm: number
  durationMin: number
  ratio?: number
  surge?: number
  extraStops?: number
  carpool?: boolean
  promoAmount?: number
  now?: Date
}

export function waitingFee(waitingMinutes: number): number {
  const paidMinutes = Math.max(0, waitingMinutes - TARIFFS.freeWaitingMinutes)
  return Math.round(paidMinutes * TARIFFS.waitingPerMinute * 100) / 100
}

export function cancellationFee(minutesSinceAssignment: number): number {
  return minutesSinceAssignment <= TARIFFS.freeCancellationMinutes
    ? 0
    : TARIFFS.cancellationFee
}

export function calculateFare(input: FareInput): FareBreakdown {
  const ratio = input.ratio ?? 1
  const surge = input.surge ?? 1
  const base = TARIFFS.base * ratio
  const distance = input.distanceKm * TARIFFS.perKm * ratio
  const duration = input.durationMin * TARIFFS.perMinute * ratio
  const stops = (input.extraStops ?? 0) * TARIFFS.extraStop
  const minimum = TARIFFS.minimum * ratio
  let subtotal = Math.max(minimum, base + distance + duration + stops) * surge
  if (input.carpool) subtotal *= 1 - TARIFFS.carpoolDiscount
  const discount = Math.min(input.promoAmount ?? 0, subtotal)
  const now = input.now ?? new Date()
  return {
    base,
    distance,
    duration,
    stops,
    surge,
    discount,
    total: Math.round((subtotal - discount) * 100) / 100,
    currency: "EUR",
    lockedUntil: new Date(
      now.getTime() + TARIFFS.priceLockMinutes * 60_000,
    ).toISOString(),
  }
}
