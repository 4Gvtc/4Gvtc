export const minutesFromMs = (milliseconds: number) =>
  Math.max(0, Math.ceil(milliseconds / 60_000))
