import { describe, expect, it } from "vitest"
import { calculateFare, cancellationFee, waitingFee } from "./fare"

describe("calculateFare", () => {
  it("respects the standard minimum", () => {
    expect(calculateFare({ distanceKm: 0, durationMin: 0 }).total).toBe(6)
  })

  it("applies vehicle ratio, surge and promo", () => {
    expect(
      calculateFare({
        distanceKm: 10,
        durationMin: 20,
        ratio: 1.38,
        surge: 1.3,
        promoAmount: 2,
      }).total,
    ).toBe(26.52)
  })

  it("charges waiting only after the free period", () => {
    expect(waitingFee(3)).toBe(0)
    expect(waitingFee(5)).toBe(0.6)
  })

  it("charges cancellation only after two minutes", () => {
    expect(cancellationFee(2)).toBe(0)
    expect(cancellationFee(2.1)).toBe(3)
  })
})
