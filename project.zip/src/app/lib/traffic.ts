export interface TrafficEstimate {
  multiplier: number
  averageSpeedKmh: number
  period: "fluid" | "busy" | "night"
}

export function trafficEstimate(date: Date): TrafficEstimate {
  const hour = date.getHours()
  const day = date.getDay()
  const weekdayPeak =
    day >= 1 &&
    day <= 5 &&
    ((hour >= 7 && hour < 9) || (hour >= 17 && hour < 19))
  if (weekdayPeak) {
    return { multiplier: 1.35, averageSpeedKmh: 21, period: "busy" }
  }
  if (hour >= 22 || hour < 6) {
    return { multiplier: 0.88, averageSpeedKmh: 32, period: "night" }
  }
  return { multiplier: 1, averageSpeedKmh: 28, period: "fluid" }
}
