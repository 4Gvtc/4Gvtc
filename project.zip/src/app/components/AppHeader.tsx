import { Moon, Sun } from "lucide-react"
import { Logo } from "./Logo"
import { IconButton } from "./ui/IconButton"
import { SelectField } from "./ui/SelectField"
import { useI18n } from "../i18n"
import { useTheme } from "../hooks/useTheme"
import type { Locale } from "../types"

export function AppHeader({ navigate }: { navigate: (path: string) => void }) {
  const { t, locale, setLocale } = useI18n()
  const { theme, toggleTheme } = useTheme()
  return (
    <header className="app-header">
      <button
        className="logo-button"
        onClick={() => navigate("/")}
        aria-label={t("nav.home")}
      >
        <Logo />
      </button>
      <div className="app-header__actions">
        <SelectField
          className="language-select"
          label={t("common.language")}
          value={locale}
          onChange={(event) => setLocale(event.target.value as Locale)}
        >
          {(["fr", "en", "de", "es", "ar"] as const).map((code) => (
            <option value={code} key={code}>
              {t(`language.${code}`)}
            </option>
          ))}
        </SelectField>
        <IconButton
          onClick={toggleTheme}
          aria-label={`${t("common.theme")}: ${
            theme === "dark" ? t("common.dark") : t("common.light")
          }`}
        >
          {theme === "dark" ? (
            <Sun aria-hidden="true" />
          ) : (
            <Moon aria-hidden="true" />
          )}
        </IconButton>
      </div>
    </header>
  )
}
