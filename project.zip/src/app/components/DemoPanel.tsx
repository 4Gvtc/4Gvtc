import { Gauge, RotateCcw, X } from "lucide-react"
import { AnimatePresence, motion } from "motion/react"
import { useState } from "react"
import { useAppState } from "../hooks/useAppState"
import { useI18n } from "../i18n"
import type { Role } from "../types"
import { Button } from "./ui/Button"
import { IconButton } from "./ui/IconButton"
import { SelectField } from "./ui/SelectField"

export function DemoPanel({ navigate }: { navigate: (path: string) => void }) {
  const { t } = useI18n()
  const { state, setRole, setSpeed, reset } = useAppState()
  const [open, setOpen] = useState(false)
  const [announcement, setAnnouncement] = useState("")
  const changeRole = (role: Role) => {
    setRole(role)
    navigate(role === "rider" ? "/" : `/${role}`)
  }
  const doReset = async () => {
    await reset()
    setAnnouncement(t("demo.resetDone"))
    navigate("/")
  }
  return (
    <>
      <Button
        variant="secondary"
        onClick={() => setOpen(true)}
        aria-expanded={open}
      >
        <Gauge aria-hidden="true" /> {t("demo.open")}{" "}
        <bdi className="speed-pill">×{state.speed}</bdi>
      </Button>
      <AnimatePresence>
        {open && (
          <motion.div
            className="modal-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpen(false)}
          >
            <motion.aside
              className="demo-panel"
              role="dialog"
              aria-modal="true"
              aria-labelledby="demo-title"
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 30, opacity: 0 }}
              transition={{ type: "spring", stiffness: 360, damping: 32 }}
              onClick={(event) => event.stopPropagation()}
            >
              <div className="demo-panel__header">
                <div>
                  <h2 id="demo-title">{t("demo.title")}</h2>
                  <p>{t("demo.description")}</p>
                </div>
                <IconButton
                  onClick={() => setOpen(false)}
                  aria-label={t("common.close")}
                >
                  <X aria-hidden="true" />
                </IconButton>
              </div>
              <SelectField
                label={t("demo.role")}
                value={state.role}
                onChange={(event) => changeRole(event.target.value as Role)}
              >
                <option value="rider">{t("roles.rider")}</option>
                <option value="driver">{t("roles.driver")}</option>
                <option value="admin">{t("roles.admin")}</option>
              </SelectField>
              <fieldset className="speed-control">
                <legend>{t("demo.speed")}</legend>
                <div>
                  {([1, 5, 10] as const).map((speed) => (
                    <Button
                      key={speed}
                      variant={state.speed === speed ? "primary" : "secondary"}
                      onClick={() => setSpeed(speed)}
                    >
                      <bdi>×{speed}</bdi>
                    </Button>
                  ))}
                </div>
              </fieldset>
              <Button variant="danger" full onClick={doReset}>
                <RotateCcw aria-hidden="true" />
                {t("common.reset")}
              </Button>
              <p className="sr-only" aria-live="polite">
                {announcement}
              </p>
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
