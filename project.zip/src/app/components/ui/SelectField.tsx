import { ChevronDown } from "lucide-react"
import type { ComponentProps } from "react"
export function SelectField({
  label,
  className = "",
  children,
  ...props
}: ComponentProps<"select"> & { label: string }) {
  return (
    <label className={`field ${className}`}>
      <span className="field__label">{label}</span>
      <span className="select-control">
        <select {...props}>{children}</select>
        <ChevronDown aria-hidden="true" />
      </span>
    </label>
  )
}
