import { motion, type HTMLMotionProps } from "motion/react"
import type { ReactNode } from "react"

type Variant = "primary" | "secondary" | "ghost" | "danger"
interface ButtonProps extends Omit<HTMLMotionProps<"button">, "children"> {
  children: ReactNode
  variant?: Variant
  full?: boolean
}

export function Button({
  children,
  variant = "primary",
  full,
  className = "",
  ...props
}: ButtonProps) {
  return (
    <motion.button
      type="button"
      whileTap={{ scale: 0.97 }}
      transition={{ type: "spring", stiffness: 520, damping: 34 }}
      className={`ui-button ui-button--${variant} ${
        full ? "ui-button--full" : ""
      } ${className}`}
      {...props}
    >
      {children}
    </motion.button>
  )
}
