import { motion, type HTMLMotionProps } from "motion/react"
import type { ReactNode } from "react"
export function IconButton({
  children,
  className = "",
  ...props
}: Omit<HTMLMotionProps<"button">, "children"> & { children: ReactNode }) {
  return (
    <motion.button
      type="button"
      whileTap={{ scale: 0.92 }}
      transition={{ type: "spring", stiffness: 520, damping: 32 }}
      className={`icon-button ${className}`}
      {...props}
    >
      {children}
    </motion.button>
  )
}
