import type { ComponentProps } from "react"
interface TextFieldProps extends ComponentProps<"input"> {
  label: string
  icon?: React.ReactNode
}
export function TextField({
  label,
  icon,
  className = "",
  ...props
}: TextFieldProps) {
  return (
    <label className={`field ${className}`}>
      <span className="field__label">{label}</span>
      <span className="field__control">
        {icon}
        <input {...props} />
      </span>
    </label>
  )
}
