import {
  Home,
  Route,
  ShieldCheck,
  UserRound,
  type LucideIcon,
} from "lucide-react"
import { useI18n, type TranslationKey } from "../i18n"

interface NavItem {
  id: string
  key: TranslationKey
  icon: LucideIcon
}

const items: NavItem[] = [
  { id: "home", key: "nav.home", icon: Home },
  { id: "rides", key: "nav.rides", icon: Route },
  { id: "safety", key: "nav.safety", icon: ShieldCheck },
  { id: "profile", key: "nav.profile", icon: UserRound },
]
export function BottomNav({
  active,
  onChange,
}: {
  active: string
  onChange: (id: string) => void
}) {
  const { t } = useI18n()
  return (
    <nav className="bottom-nav" aria-label={t("common.menu")}>
      {items.map(({ id, key, icon: Icon }) => (
        <button
          key={id}
          className={active === id ? "is-active" : ""}
          aria-current={active === id ? "page" : undefined}
          onClick={() => onChange(id)}
        >
          <span>
            <Icon aria-hidden="true" />
          </span>
          <small>{t(key)}</small>
        </button>
      ))}
    </nav>
  )
}
