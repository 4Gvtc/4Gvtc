import {
  Crosshair,
  LocateFixed,
  Minus,
  Navigation,
  Plus,
  SignalLow,
  TrafficCone,
} from "lucide-react"
import { useEffect, useMemo, useRef, useState } from "react"
import { DRIVERS } from "../data/drivers"
import { BORDEAUX_CENTER } from "../data/places"
import { useAppState } from "../hooks/useAppState"
import { useConnectivity } from "../hooks/useConnectivity"
import { useMediaQuery } from "../hooks/useMediaQuery"
import { useTheme } from "../hooks/useTheme"
import { useI18n } from "../i18n"
import {
  mapProvider,
  type MapController,
  type MapMarker,
  type MapRenderState,
  type MapRoute,
} from "../integrations/maps"
import { dataStore } from "../integrations/store"
import { bearing, haversine } from "../lib/geo"
import { trafficEstimate } from "../lib/traffic"
import type { BookingDraft, Coordinates } from "../types"
import { IconButton } from "./ui/IconButton"

interface WatchedLocation {
  position: Coordinates
  accuracyMeters: number
}

export function BordeauxMap() {
  const { t } = useI18n()
  const { state } = useAppState()
  const { theme } = useTheme()
  const offline = useConnectivity()
  const desktop = useMediaQuery("(min-width: 1024px)")
  const containerRef = useRef<HTMLDivElement>(null)
  const controllerRef = useRef<MapController | null>(null)
  const draftRef = useRef<BookingDraft | null>(null)
  const previousPositions = useRef<Record<string, Coordinates>>({})
  const lastFitKey = useRef("")
  const [draft, setDraft] = useState<BookingDraft | null>(null)
  const [location, setLocation] = useState<WatchedLocation | null>(null)
  const [locationDenied, setLocationDenied] = useState(false)

  useEffect(
    () =>
      dataStore.subscribe<BookingDraft>("booking/session", (session) => {
        if (!session) return
        draftRef.current = session
        setDraft(session)
      }),
    [],
  )

  useEffect(() => {
    if (!navigator.geolocation) {
      setLocationDenied(true)
      return
    }
    const watchId = navigator.geolocation.watchPosition(
      ({ coords }) => {
        setLocationDenied(false)
        setLocation({
          position: { lat: coords.latitude, lon: coords.longitude },
          accuracyMeters: coords.accuracy,
        })
      },
      (error) => {
        if (error.code === error.PERMISSION_DENIED) {
          setLocationDenied(true)
          controllerRef.current?.recenter(BORDEAUX_CENTER, 13)
        }
      },
      {
        enableHighAccuracy: true,
        maximumAge: 8_000,
        timeout: 12_000,
      },
    )
    return () => navigator.geolocation.clearWatch(watchId)
  }, [])

  const activeRide = useMemo(
    () =>
      [...state.rides]
        .reverse()
        .find((ride) => !["completed", "cancelled"].includes(ride.status)),
    [state.rides],
  )
  const assignedPosition = activeRide?.driverId
    ? state.driverPositions[activeRide.driverId]
    : undefined

  const routes = useMemo<MapRoute[]>(() => {
    if (
      activeRide?.route?.length &&
      assignedPosition &&
      (activeRide.status === "driver_assigned" ||
        activeRide.status === "in_progress")
    ) {
      const nearestIndex = activeRide.route.reduce(
        (nearest, point, index, points) =>
          haversine(assignedPosition, point) <
          haversine(assignedPosition, points[nearest]!)
            ? index
            : nearest,
        0,
      )
      return [
        {
          id: activeRide.id,
          points: activeRide.route.slice(nearestIndex),
          selected: true,
          alternative: false,
        },
      ]
    }
    if (draft?.routes.length) {
      return draft.routes.map((route, index) => ({
        id: route.id,
        points: route.geometry,
        selected: route.id === draft.selectedRouteId,
        alternative: index > 0,
      }))
    }
    if (activeRide?.route?.length) {
      return [
        {
          id: activeRide.id,
          points: activeRide.route,
          selected: true,
          alternative: false,
        },
      ]
    }
    return []
  }, [activeRide, assignedPosition, draft])

  const markers = useMemo<MapMarker[]>(() => {
    const result: MapMarker[] = []
    const origin = draft?.origin ?? activeRide?.stops[0]
    const destination = draft?.destination ?? activeRide?.stops.at(-1)
    const intermediateStops =
      draft?.intermediateStops ?? activeRide?.stops.slice(1, -1) ?? []
    if (origin) {
      result.push({
        id: "origin",
        position: origin,
        kind: "origin",
        label: origin.name,
      })
    }
    intermediateStops.forEach((stop, index) => {
      result.push({
        id: `stop-${index}`,
        position: stop,
        kind: "stop",
        index: index + 1,
        label: stop.name,
      })
    })
    if (destination) {
      result.push({
        id: "destination",
        position: destination,
        kind: "destination",
        label: destination.name,
      })
    }
    if (location) {
      result.push({
        id: "user",
        position: location.position,
        kind: "user",
        accuracyMeters: location.accuracyMeters,
        label: t("home.currentLocation"),
      })
    }

    DRIVERS.filter((driver) => {
      const isAssigned = activeRide?.driverId === driver.id
      const isAvailable = state.driverStatuses[driver.id] === "available"
      return isAssigned || isAvailable
    }).forEach((driver) => {
      const position = state.driverPositions[driver.id] ?? driver.position
      const previous = previousPositions.current[driver.id]
      result.push({
        id: `driver-${driver.id}`,
        position,
        kind: "driver",
        heading: previous ? bearing(previous, position) : 0,
        label: driver.name,
      })
      previousPositions.current[driver.id] = position
    })
    return result
  }, [
    activeRide,
    draft,
    location,
    state.driverPositions,
    state.driverStatuses,
    t,
  ])

  const renderState = useMemo<MapRenderState>(
    () => ({
      theme,
      center: location?.position ?? BORDEAUX_CENTER,
      zoom: 13,
      markers,
      routes,
      bottomPadding: desktop ? 36 : 280,
    }),
    [desktop, location, markers, routes, theme],
  )

  useEffect(() => {
    const element = containerRef.current
    if (!element) return
    const controller = mapProvider.mount(element, renderState, {
      onAlternativeSelect: (routeId) => {
        const current = draftRef.current
        if (!current) return
        const next = { ...current, selectedRouteId: routeId }
        draftRef.current = next
        setDraft(next)
        void dataStore.create("booking/session", next)
      },
    })
    controllerRef.current = controller
    return () => {
      controller.destroy()
      controllerRef.current = null
    }
  }, [])

  useEffect(() => {
    controllerRef.current?.update(renderState)
    const fitKey = [
      routes.map((route) => route.id).join(","),
      draft?.origin?.id,
      draft?.destination?.id,
      draft?.intermediateStops.map((stop) => stop.id).join(","),
    ].join("|")
    if (
      fitKey !== lastFitKey.current &&
      (routes.length || draft?.destination)
    ) {
      lastFitKey.current = fitKey
      window.requestAnimationFrame(() => controllerRef.current?.fitBounds())
    }
  }, [draft, renderState, routes])

  const destination = draft?.destination ?? activeRide?.stops.at(-1)
  const traffic = trafficEstimate(new Date())
  const etaMinutes =
    assignedPosition && destination
      ? Math.max(
          1,
          Math.round(
            ((haversine(assignedPosition, destination) * 1.35) /
              traffic.averageSpeedKmh) *
              60,
          ),
        )
      : routes.find((route) => route.selected)
        ? Math.round(
            (draft?.routes.find((route) => route.id === draft.selectedRouteId)
              ?.durationMin ?? 0) * traffic.multiplier,
          )
        : null

  const goToUser = () => {
    if (location) {
      controllerRef.current?.recenter(location.position, 16)
      return
    }
    setLocationDenied(true)
    controllerRef.current?.recenter(BORDEAUX_CENTER, 13)
  }

  return (
    <div className="map leaflet-map" dir="ltr">
      <div
        ref={containerRef}
        className="leaflet-map__canvas"
        role="application"
        aria-label={t("home.mapLabel")}
      />
      {offline && (
        <div className="map-offline-banner" role="status">
          <SignalLow aria-hidden="true" />
          <span>{t("map.offline")}</span>
        </div>
      )}
      {locationDenied && (
        <div className="map-location-banner" role="status">
          <LocateFixed aria-hidden="true" />
          <span>
            <strong>{t("map.locationDeniedTitle")}</strong>
            <small>{t("map.locationDeniedDescription")}</small>
          </span>
        </div>
      )}
      {etaMinutes !== null && etaMinutes > 0 && (
        <div className="map-traffic-card">
          <TrafficCone aria-hidden="true" />
          <span>
            <strong>{t("map.trafficEta", { minutes: etaMinutes })}</strong>
            <small>{t("map.trafficEstimate")}</small>
          </span>
        </div>
      )}
      <div className="map-controls map-controls--zoom">
        <IconButton
          onClick={() => controllerRef.current?.zoomIn()}
          aria-label={t("map.zoomIn")}
        >
          <Plus aria-hidden="true" />
        </IconButton>
        <IconButton
          onClick={() => controllerRef.current?.zoomOut()}
          aria-label={t("map.zoomOut")}
        >
          <Minus aria-hidden="true" />
        </IconButton>
      </div>
      <div className="map-controls map-controls--position">
        <IconButton
          onClick={() => controllerRef.current?.fitBounds()}
          aria-label={t("map.recenter")}
        >
          <Crosshair aria-hidden="true" />
        </IconButton>
        <IconButton onClick={goToUser} aria-label={t("map.myLocation")}>
          <Navigation aria-hidden="true" />
        </IconButton>
      </div>
      <span className="map__attribution">{t("home.mapAttribution")}</span>
    </div>
  )
}
