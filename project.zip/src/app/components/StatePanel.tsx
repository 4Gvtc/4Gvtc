import {
  AlertTriangle,
  Check,
  Inbox,
  LoaderCircle,
  type LucideIcon,
} from "lucide-react"
import { useI18n, type TranslationKey } from "../i18n"

const icons: Record<"empty" | "error" | "success" | "loading", LucideIcon> = {
  empty: Inbox,
  error: AlertTriangle,
  success: Check,
  loading: LoaderCircle,
}
export function StatePanel({
  kind,
  titleKey,
  descriptionKey,
}: {
  kind: keyof typeof icons
  titleKey: TranslationKey
  descriptionKey?: TranslationKey
}) {
  const { t } = useI18n()
  const Icon = icons[kind]
  return (
    <div
      className={`state state--${kind}`}
      role={kind === "error" ? "alert" : "status"}
    >
      <span className="state__icon">
        <Icon aria-hidden="true" />
      </span>
      <strong>{t(titleKey)}</strong>
      {descriptionKey && <p>{t(descriptionKey)}</p>}
      {kind === "loading" && <span className="skeleton-line" />}
    </div>
  )
}
