export function VehicleGlyph({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 48 24" aria-hidden="true">
      <path
        d="M6 17.5h2.5m31 0H42M11 17.5h26M13 8.5l4-4h13l6 4 3 7H9l4-7Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle
        cx="14"
        cy="18"
        r="3"
        fill="var(--surface)"
        stroke="currentColor"
        strokeWidth="1.75"
      />
      <circle
        cx="35"
        cy="18"
        r="3"
        fill="var(--surface)"
        stroke="currentColor"
        strokeWidth="1.75"
      />
      <path
        d="M18 5v4h16"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.75"
      />
    </svg>
  )
}
