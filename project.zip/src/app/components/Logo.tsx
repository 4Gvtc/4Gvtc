import { useState } from "react"
import { useI18n } from "../i18n"
export function Logo({ compact = false }: { compact?: boolean }) {
  const { t } = useI18n()
  const [failed, setFailed] = useState(false)
  return (
    <div className="logo">
      <span className="logo__mark">
        {!failed ? (
          <img src="/4g-vtc-logo.webp" alt="" onError={() => setFailed(true)} />
        ) : (
          <span>4G</span>
        )}
      </span>
      {!compact && (
        <span className="logo__copy">
          <strong>{t("brand.name")}</strong>
          <small>{t("brand.tagline")}</small>
        </span>
      )}
    </div>
  )
}
