export type Role = "rider" | "driver" | "admin"
export type Locale = "fr" | "en" | "de" | "es" | "ar"
export type Theme = "light" | "dark"

export interface Coordinates {
  lat: number
  lon: number
}

export interface User {
  id: string
  role: Role
  createdAt: string
}

export interface RiderProfile {
  userId: string
  completedRideIds: string[]
  loyaltyPoints: number
}

export interface DriverProfile {
  id: string
  name: string
  vehicle: string
  color: string
  licence: string
  plate: string
  insurance: string
  verification: "pending" | "verified" | "rejected"
  womenOnly: boolean
  level: string
  experienceYears: number
  languages: Locale[]
  rating: number
  position: Coordinates
  status: "offline" | "available" | "on_ride"
}

export interface VehicleType {
  id: string
  nameKey: string
  group: string
  capacity: number
  baseEtaMin: number
  fareRatio: number
  emissionGramsKm: number
}

export type RideStatus = "scheduled" | "searching" | "driver_assigned" | "driver_arrived" | "in_progress" | "completed" | "cancelled"

export interface FareBreakdown {
  base: number
  distance: number
  duration: number
  stops: number
  surge: number
  discount: number
  total: number
  currency: "EUR"
  lockedUntil: string
}

export interface Place extends Coordinates {
  id: string
  name: string
  address: string
}

export interface Ride {
  id: string
  riderId: string
  driverId?: string
  status: RideStatus
  stops: Place[]
  fare: FareBreakdown
  vehicleTypeId: string
  surge: number
  promo?: string
  tip: number
  paymentMethod: string
  pin: string
  womenOnly: boolean
  carpool: boolean
  splitCount: 1 | 2 | 3 | 4
  sos: boolean
  createdAt: string
  scheduledFor?: string
  completedAt?: string
  rating?: 1 | 2 | 3 | 4 | 5
  route?: Coordinates[]
}

export interface SavedPlace extends Place {
  userId: string
}
export interface PaymentMethod {
  id: string
  type: "cash" | "card" | "apple_pay" | "google_pay" | "paypal"
  isDefault: boolean
}
export interface PromoCode {
  code: string
  amountOff: number
  maxUses: number
}
export interface Notification {
  id: string
  titleKey: string
  createdAt: string
  read: boolean
}
export interface ChatMessage {
  id: string
  rideId: string
  senderId: string
  body: string
  createdAt: string
}
export interface Dispute {
  id: string
  rideId: string
  status: "open" | "resolved"
}
export interface LoyaltyTier {
  id: string
  ridesRequired: number
  cashbackPercent: number
}
export interface Subscription {
  id: string
  userId: string
  active: boolean
}
export interface Referral {
  id: string
  ownerId: string
  redeemedAt?: string
}

export interface AppState {
  role: Role
  speed: 1 | 5 | 10
  rides: Ride[]
  notifications: Notification[]
  paymentMethods: PaymentMethod[]
  savedPlaces: SavedPlace[]
  driverPositions: Record<string, Coordinates>
  driverStatuses: Record<string, DriverProfile["status"]>
  usedPromoCodes: string[]
}

export type BookingStep = "locations" | "route" | "vehicle" | "confirm" | "searching" | "assigned" | "in_progress" | "complete" | "receipt"

export interface RouteOption {
  id: string
  distanceKm: number
  durationMin: number
  geometry: Coordinates[]
}

export interface BookingDraft {
  step: BookingStep
  origin: Place | null
  destination: Place | null
  intermediateStops: Place[]
  routes: RouteOption[]
  selectedRouteId: string | null
  vehicleTypeId: string
  electricOnly: boolean
  carpool: boolean
  womenOnly: boolean
  promoCode: string | null
  splitCount: 1 | 2 | 3 | 4
  paymentMethod: string
  scheduledFor: string | null
  assignedDriverId: string | null
  pin: string | null
  rating: 1 | 2 | 3 | 4 | 5 | null
  tip: number
  sos: boolean
  rideId: string | null
}
