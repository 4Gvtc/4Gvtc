import { LayoutDashboard, UserRound } from "lucide-react"
import { BordeauxMap } from "../../components/BordeauxMap"
import { DemoPanel } from "../../components/DemoPanel"
import { StatePanel } from "../../components/StatePanel"
import { useI18n } from "../../i18n"
import type { Role } from "../../types"

export default function RolePage({
  role,
  navigate,
}: {
  role: Exclude<Role, "rider">
  navigate: (path: string) => void
}) {
  const { t } = useI18n()
  const Icon = role === "driver" ? UserRound : LayoutDashboard
  return (
    <main id="main-content" className="home-layout role-layout">
      <section className="control-panel">
        <div className="role-intro">
          <span>
            <Icon aria-hidden="true" />
          </span>
          <p className="eyebrow">
            {t(role === "driver" ? "roles.driver" : "roles.admin")}
          </p>
          <h1>
            {t(
              role === "driver"
                ? "rolePage.driverTitle"
                : "rolePage.adminTitle",
            )}
          </h1>
          <p>
            {t(
              role === "driver"
                ? "rolePage.driverDescription"
                : "rolePage.adminDescription",
            )}
          </p>
        </div>
        <div className="home-content">
          <StatePanel
            kind="empty"
            titleKey="home.emptyTitle"
            descriptionKey="home.emptyDescription"
          />
          <DemoPanel navigate={navigate} />
        </div>
      </section>
      <section className="map-panel">
        <BordeauxMap />
      </section>
    </main>
  )
}
