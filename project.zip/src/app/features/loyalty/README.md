# Loyalty
Computed loyalty tiers and cashback.
