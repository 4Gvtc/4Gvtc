import { AlertTriangle, ArrowLeft, Check, MapPin } from "lucide-react"
import { motion } from "motion/react"
import { useState } from "react"
import { StatePanel } from "../../components/StatePanel"
import { Button } from "../../components/ui/Button"
import { IconButton } from "../../components/ui/IconButton"
import { Surface } from "../../components/ui/Surface"
import { TextField } from "../../components/ui/TextField"
import { useI18n } from "../../i18n"

export default function DesignSystemPage({
  navigate,
}: {
  navigate: (path: string) => void
}) {
  const { t } = useI18n()
  const [sheet, setSheet] = useState(false)
  return (
    <main id="main-content" className="design-page">
      <header className="design-page__header">
        <IconButton onClick={() => navigate("/")} aria-label={t("nav.home")}>
          <ArrowLeft className="directional-icon" aria-hidden="true" />
        </IconButton>
        <div>
          <p className="eyebrow">{t("brand.name")}</p>
          <h1>{t("design.title")}</h1>
          <p>{t("design.description")}</p>
        </div>
      </header>
      <div className="design-grid">
        <Surface>
          <h2>{t("design.colors")}</h2>
          <div className="swatches">
            {([
              "surface",
              "primary",
              "accent",
              "success",
              "danger",
            ] as const).map((color) => (
              <div key={color}>
                <span className={`swatch swatch--${color}`} />
                <small>{t(`design.${color}`)}</small>
              </div>
            ))}
          </div>
        </Surface>
        <Surface>
          <h2>{t("design.typography")}</h2>
          <h3>{t("design.headingSample")}</h3>
          <p>{t("design.bodySample")}</p>
          <strong className="price" dir="ltr">
            {t("design.priceSample")}
          </strong>
        </Surface>
        <Surface>
          <h2>{t("design.controls")}</h2>
          <div className="control-showcase">
            <Button onClick={() => setSheet(true)}>
              {t("design.primaryAction")}
            </Button>
            <Button
              variant="secondary"
              onClick={() => setSheet((value) => !value)}
            >
              {t("design.secondaryAction")}
            </Button>
            <TextField
              label={t("design.inputLabel")}
              placeholder={t("design.inputPlaceholder")}
              icon={<MapPin aria-hidden="true" />}
            />
            <span className="chip">
              <Check aria-hidden="true" />
              {t("design.chip")}
            </span>
          </div>
        </Surface>
        <Surface className="states-surface">
          <h2>{t("design.states")}</h2>
          <div className="states-grid">
            <StatePanel
              kind="empty"
              titleKey="states.emptyTitle"
              descriptionKey="states.emptyDescription"
            />
            <StatePanel
              kind="error"
              titleKey="states.errorTitle"
              descriptionKey="states.errorDescription"
            />
            <StatePanel
              kind="success"
              titleKey="states.successTitle"
              descriptionKey="states.successDescription"
            />
            <StatePanel kind="loading" titleKey="states.loadingTitle" />
          </div>
        </Surface>
        <Surface>
          <h2>{t("design.rtlPreview")}</h2>
          <div className="rtl-preview" dir="rtl">
            <AlertTriangle aria-hidden="true" />
            <span>{t("states.errorDescription")}</span>
            <ArrowLeft className="directional-icon" aria-hidden="true" />
          </div>
        </Surface>
      </div>
      {sheet && (
        <motion.aside
          className="sample-sheet"
          drag="y"
          dragConstraints={{ top: 0, bottom: 180 }}
          dragElastic={0.08}
          initial={{ y: 220 }}
          animate={{ y: 0 }}
          transition={{ type: "spring", stiffness: 330, damping: 30 }}
        >
          <span className="sheet-handle" />
          <h2>{t("sheet.title")}</h2>
          <p>{t("sheet.description")}</p>
          <Button full variant="secondary" onClick={() => setSheet(false)}>
            {t("common.close")}
          </Button>
        </motion.aside>
      )}
    </main>
  )
}
