import { useEffect, useMemo, useState } from "react"
import { PROMOS } from "../../data/promos"
import { surgeFor } from "../../data/tariffs"
import { VEHICLES } from "../../data/vehicles"
import { useAppState } from "../../hooks/useAppState"
import { dispatchService } from "../../integrations/dispatch"
import { routingProvider } from "../../integrations/routing"
import { dataStore } from "../../integrations/store"
import { calculateFare, cancellationFee } from "../../lib/fare"
import { createId } from "../../lib/id"
import type {
  BookingDraft,
  DriverProfile,
  FareBreakdown,
  Ride,
  RouteOption,
} from "../../types"

const SESSION_PATH = "booking/session"
const initialDraft: BookingDraft = {
  step: "locations",
  origin: null,
  destination: null,
  intermediateStops: [],
  routes: [],
  selectedRouteId: null,
  vehicleTypeId: "std",
  electricOnly: false,
  carpool: false,
  womenOnly: false,
  promoCode: null,
  splitCount: 1,
  paymentMethod: "cash",
  scheduledFor: null,
  assignedDriverId: null,
  pin: null,
  rating: null,
  tip: 0,
  sos: false,
  rideId: null,
}

export function useBookingMachine() {
  const { state, saveRide, markPromoUsed, setDriverStatus } = useAppState()
  const [draft, setDraftState] = useState<BookingDraft>(initialDraft)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(
    () =>
      dataStore.subscribe<BookingDraft>(SESSION_PATH, (stored) => {
        if (stored) setDraftState({ ...initialDraft, ...stored })
      }),
    [],
  )

  const setDraft = (
    update: Partial<BookingDraft> | ((current: BookingDraft) => BookingDraft),
  ) => {
    setDraftState((current) => {
      const next =
        typeof update === "function"
          ? update(current)
          : { ...current, ...update }
      void dataStore.create(SESSION_PATH, next)
      return next
    })
  }

  const selectedRoute =
    draft.routes.find((route) => route.id === draft.selectedRouteId) ?? null
  const selectedVehicle =
    VEHICLES.find((vehicle) => vehicle.id === draft.vehicleTypeId) ??
    VEHICLES[2]!
  const fareFor = (
    vehicleId: string,
    withPromo = draft.promoCode === "RIDE20",
  ): FareBreakdown | null => {
    if (!selectedRoute) return null
    const vehicle =
      VEHICLES.find((item) => item.id === vehicleId) ?? VEHICLES[2]!
    return calculateFare({
      distanceKm: selectedRoute.distanceKm,
      durationMin: selectedRoute.durationMin,
      ratio: vehicle.fareRatio,
      surge: surgeFor(new Date(draft.scheduledFor ?? Date.now())),
      extraStops: draft.intermediateStops.length,
      carpool: draft.carpool,
      promoAmount: withPromo ? PROMOS[0]!.amountOff : 0,
    })
  }
  const fare = fareFor(draft.vehicleTypeId)

  const calculateRoutes = async () => {
    if (!draft.origin || !draft.destination) return
    setBusy(true)
    setError(null)
    try {
      const points = [
        draft.origin,
        ...draft.intermediateStops,
        draft.destination,
      ]
      const result = await routingProvider.route(points)
      const routes: RouteOption[] = [
        {
          id: "main",
          distanceKm: result.distanceKm,
          durationMin: result.durationMin,
          geometry: result.geometry,
        },
        ...result.alternatives.map((route, index) => ({
          id: `alternative-${index + 1}`,
          ...route,
        })),
      ]
      setDraft({
        routes,
        selectedRouteId: routes[0]!.id,
        step: "route",
      })
    } catch {
      setError("routing")
    } finally {
      setBusy(false)
    }
  }

  const createRide = (): Ride | null => {
    if (!draft.origin || !draft.destination || !fare || !selectedRoute)
      return null
    const pinArray = new Uint16Array(1)
    crypto.getRandomValues(pinArray)
    const pin = String(1000 + (pinArray[0]! % 9000))
    const scheduled =
      draft.scheduledFor &&
      new Date(draft.scheduledFor).getTime() > Date.now() + 60_000
    const ride: Ride = {
      id: createId("ride"),
      riderId: "local-rider",
      status: scheduled ? "scheduled" : "searching",
      stops: [draft.origin, ...draft.intermediateStops, draft.destination],
      fare,
      vehicleTypeId: selectedVehicle.id,
      surge: fare.surge,
      promo: draft.promoCode ?? undefined,
      tip: 0,
      paymentMethod: draft.paymentMethod,
      pin,
      womenOnly: draft.womenOnly,
      carpool: draft.carpool,
      splitCount: draft.splitCount,
      sos: false,
      createdAt: new Date().toISOString(),
      scheduledFor: draft.scheduledFor ?? undefined,
      route: selectedRoute.geometry,
    }
    saveRide(ride)
    if (draft.promoCode) markPromoUsed(draft.promoCode)
    setDraft({
      rideId: ride.id,
      pin,
      step: scheduled ? "receipt" : "searching",
    })
    return ride
  }

  const activeRide =
    state.rides.find((ride) => ride.id === draft.rideId) ?? null
  const updateRide = (changes: Partial<Ride>) => {
    if (!activeRide) return
    saveRide({ ...activeRide, ...changes })
  }

  const findDriver = async (
    excluded: string[],
  ): Promise<DriverProfile | null> => {
    if (!activeRide) return null
    return dispatchService.assignDriver(activeRide, excluded)
  }

  const assignDriver = (driver: DriverProfile) => {
    updateRide({ driverId: driver.id, status: "driver_assigned" })
    setDriverStatus(driver.id, "on_ride")
    setDraft({ assignedDriverId: driver.id, step: "assigned" })
  }

  const cancelRide = () => {
    if (activeRide) {
      const elapsedMinutes =
        (Date.now() - new Date(activeRide.createdAt).getTime()) / 60_000
      const fee = activeRide.driverId ? cancellationFee(elapsedMinutes) : 0
      updateRide({
        status: "cancelled",
        fare: {
          ...activeRide.fare,
          total: fee,
        },
      })
      if (activeRide.driverId) {
        setDriverStatus(activeRide.driverId, "available")
      }
    }
    setDraft({ ...initialDraft })
  }

  const startRide = () => {
    updateRide({ status: "in_progress" })
    setDraft({ step: "in_progress" })
  }

  const setSos = () => {
    updateRide({ sos: true })
  }

  const finishRide = () => {
    updateRide({
      status: "completed",
      completedAt: new Date().toISOString(),
    })
    if (activeRide?.driverId) {
      setDriverStatus(activeRide.driverId, "available")
    }
    setDraft({ step: "complete" })
  }

  const submitReview = () => {
    updateRide({ rating: draft.rating ?? undefined, tip: draft.tip })
    setDraft({ step: "receipt" })
  }

  const reset = async () => {
    setDraftState(initialDraft)
    await dataStore.create(SESSION_PATH, initialDraft)
  }

  const recentPlaces = useMemo(
    () =>
      state.rides
        .filter((ride) => ride.status === "completed")
        .sort((a, b) =>
          (b.completedAt ?? "").localeCompare(a.completedAt ?? ""),
        )
        .flatMap((ride) => ride.stops.slice(-1))
        .filter(
          (place, index, all) =>
            all.findIndex((item) => item.id === place.id) === index,
        )
        .slice(0, 3),
    [state.rides],
  )

  return {
    draft,
    setDraft,
    busy,
    error,
    setError,
    selectedRoute,
    selectedVehicle,
    fare,
    fareFor,
    calculateRoutes,
    createRide,
    activeRide,
    findDriver,
    assignDriver,
    cancelRide,
    startRide,
    setSos,
    finishRide,
    submitReview,
    reset,
    recentPlaces,
  }
}

export type BookingMachine = ReturnType<typeof useBookingMachine>
