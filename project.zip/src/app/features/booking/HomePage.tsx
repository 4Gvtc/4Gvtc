import { Route, Star } from "lucide-react"
import { AnimatePresence, motion } from "motion/react"
import { useState } from "react"
import { BordeauxMap } from "../../components/BordeauxMap"
import { BottomNav } from "../../components/BottomNav"
import { DemoPanel } from "../../components/DemoPanel"
import { StatePanel } from "../../components/StatePanel"
import { LOYALTY_TIERS } from "../../data/loyalty"
import { useAppState } from "../../hooks/useAppState"
import { useI18n } from "../../i18n"
import { formatMoney, localeTags } from "../../lib/format"
import { BookingFlow } from "./BookingFlow"

export default function HomePage({
  navigate,
}: {
  navigate: (path: string) => void
}) {
  const [active, setActive] = useState("home")
  return (
    <main id="main-content" className="home-layout booking-layout">
      <section className="control-panel booking-control">
        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            className="tab-content"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {active === "home" && <BookingFlow />}
            {active === "rides" && <HistoryPanel />}
            {active === "safety" && (
              <div className="secondary-tab">
                <StatePanel
                  kind="success"
                  titleKey="nav.safety"
                  descriptionKey="states.successDescription"
                />
                <DemoPanel navigate={navigate} />
              </div>
            )}
            {active === "profile" && (
              <div className="secondary-tab">
                <LoyaltyPanel />
                <DemoPanel navigate={navigate} />
              </div>
            )}
          </motion.div>
        </AnimatePresence>
        <BottomNav active={active} onChange={setActive} />
      </section>
      <section className="map-panel">
        <BordeauxMap />
      </section>
    </main>
  )
}

function HistoryPanel() {
  const { t, locale } = useI18n()
  const { state } = useAppState()
  const rides = state.rides
    .filter((ride) => ride.status === "completed")
    .sort((a, b) => (b.completedAt ?? "").localeCompare(a.completedAt ?? ""))
  return (
    <div className="secondary-tab">
      <header className="tab-header">
        <span>
          <Route aria-hidden="true" />
        </span>
        <h1>{t("history.title")}</h1>
      </header>
      {rides.length === 0 ? (
        <StatePanel
          kind="empty"
          titleKey="home.emptyTitle"
          descriptionKey="history.empty"
        />
      ) : (
        <div className="history-list">
          {rides.map((ride) => (
            <article key={ride.id}>
              <div>
                <strong>{ride.stops.at(-1)?.name}</strong>
                <small>
                  {new Intl.DateTimeFormat(localeTags[locale], {
                    dateStyle: "medium",
                    timeStyle: "short",
                  }).format(new Date(ride.completedAt ?? ride.createdAt))}
                </small>
              </div>
              <bdi className="price">
                {formatMoney(ride.fare.total + ride.tip, locale)}
              </bdi>
            </article>
          ))}
        </div>
      )}
    </div>
  )
}

function LoyaltyPanel() {
  const { t } = useI18n()
  const { state } = useAppState()
  const count = state.rides.filter((ride) => ride.status === "completed").length
  const tier =
    [...LOYALTY_TIERS].reverse().find((item) => count >= item.ridesRequired) ??
    LOYALTY_TIERS[0]!
  return (
    <section className="profile-loyalty">
      <span>
        <Star aria-hidden="true" />
      </span>
      <p>{t("loyalty.title")}</p>
      <h1>{t("loyalty.tier", { tier: tier.id })}</h1>
      <strong>{t("loyalty.rides", { count })}</strong>
    </section>
  )
}
