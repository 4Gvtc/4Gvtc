import {
  AlertTriangle,
  ArrowLeft,
  BatteryCharging,
  CalendarClock,
  Check,
  ChevronRight,
  CircleDollarSign,
  Clock3,
  CreditCard,
  Leaf,
  MapPin,
  Navigation,
  Plus,
  ReceiptText,
  Route,
  Search,
  Share2,
  ShieldAlert,
  Star,
  Users,
  X,
} from "lucide-react"
import { AnimatePresence, motion, type PanInfo } from "motion/react"
import { useEffect, useMemo, useState } from "react"
import { StatePanel } from "../../components/StatePanel"
import { VehicleGlyph } from "../../components/VehicleGlyph"
import { Button } from "../../components/ui/Button"
import { IconButton } from "../../components/ui/IconButton"
import { Switch } from "../../components/ui/Switch"
import { TextField } from "../../components/ui/TextField"
import { DRIVERS } from "../../data/drivers"
import { LOYALTY_TIERS } from "../../data/loyalty"
import { BORDEAUX_CENTER } from "../../data/places"
import { VEHICLES } from "../../data/vehicles"
import { useAppState } from "../../hooks/useAppState"
import { useMediaQuery } from "../../hooks/useMediaQuery"
import { useI18n } from "../../i18n"
import { geocodingProvider } from "../../integrations/geocoding"
import { formatDistance, formatMoney, localeTags } from "../../lib/format"
import type { BookingStep, Place } from "../../types"
import { LocationPicker } from "./LocationPicker"
import { type BookingMachine, useBookingMachine } from "./useBookingMachine"

const backSteps: Partial<Record<BookingStep, BookingStep>> = {
  route: "locations",
  vehicle: "route",
  confirm: "vehicle",
}

export function BookingFlow() {
  const machine = useBookingMachine()
  const { t } = useI18n()
  const desktop = useMediaQuery("(min-width: 1024px)")
  const [collapsed, setCollapsed] = useState(false)
  const handleDrag = (_: PointerEvent, info: PanInfo) => {
    if (desktop) return
    if (info.offset.y > 90 || info.velocity.y > 500) setCollapsed(true)
    if (info.offset.y < -60 || info.velocity.y < -500) setCollapsed(false)
  }
  const canDrag = !desktop && machine.draft.step === "locations"
  const back = backSteps[machine.draft.step]

  return (
    <motion.section
      className={`booking-sheet ${collapsed ? "is-collapsed" : ""}`}
      drag={canDrag ? "y" : false}
      dragConstraints={{ top: 0, bottom: 260 }}
      dragElastic={0.08}
      onDragEnd={handleDrag}
      animate={{ y: collapsed && canDrag ? 230 : 0 }}
      transition={{ type: "spring", stiffness: 380, damping: 36 }}
      aria-label={t("home.destinationLabel")}
    >
      {canDrag && (
        <button
          type="button"
          className="booking-sheet__handle"
          onClick={() => setCollapsed((value) => !value)}
          aria-expanded={!collapsed}
        >
          <span />
        </button>
      )}
      <header className="booking-header">
        {back ? (
          <IconButton
            onClick={() => machine.setDraft({ step: back })}
            aria-label={t("booking.back")}
          >
            <ArrowLeft className="directional-icon" aria-hidden="true" />
          </IconButton>
        ) : (
          <span className="booking-header__icon">
            <Navigation aria-hidden="true" />
          </span>
        )}
        <div>
          <small>{t(`booking.step.${machine.draft.step}` as never)}</small>
          <h1>{stepTitle(machine.draft.step, t)}</h1>
        </div>
      </header>
      <div className="booking-progress" aria-hidden="true">
        <span className={`booking-progress--${machine.draft.step}`} />
      </div>
      <div className="booking-live sr-only" aria-live="polite">
        {stepTitle(machine.draft.step, t)}
      </div>
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={machine.draft.step}
          className="booking-step"
          initial={{ opacity: 0, x: 18 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -12 }}
          transition={{ type: "spring", stiffness: 430, damping: 36 }}
        >
          <Step machine={machine} />
        </motion.div>
      </AnimatePresence>
    </motion.section>
  )
}

function Step({ machine }: { machine: BookingMachine }) {
  switch (machine.draft.step) {
    case "locations":
      return <LocationsStep machine={machine} />
    case "route":
      return <RouteStep machine={machine} />
    case "vehicle":
      return <VehicleStep machine={machine} />
    case "confirm":
      return <ConfirmStep machine={machine} />
    case "searching":
      return <SearchingStep machine={machine} />
    case "assigned":
      return <AssignedStep machine={machine} />
    case "in_progress":
      return <ProgressStep machine={machine} />
    case "complete":
      return <CompleteStep machine={machine} />
    case "receipt":
      return <ReceiptStep machine={machine} />
  }
}

function LocationsStep({ machine }: { machine: BookingMachine }) {
  const { t } = useI18n()
  const { state } = useAppState()
  const [addingStop, setAddingStop] = useState(false)
  const [message, setMessage] = useState("")
  const useLocation = () => {
    if (!navigator.geolocation) {
      setMessage(t("booking.locationError"))
      return
    }
    navigator.geolocation.getCurrentPosition(
      async ({ coords }) => {
        const place = (await geocodingProvider.reverse(
          coords.latitude,
          coords.longitude,
        )) ?? {
          id: "current",
          name: t("booking.currentLocation"),
          address: t("booking.currentLocation"),
          lat: coords.latitude,
          lon: coords.longitude,
        }
        machine.setDraft({ origin: { ...place, id: "current" } })
      },
      () => setMessage(t("booking.locationError")),
    )
  }
  const continueToRoute = () => {
    if (!machine.draft.origin || !machine.draft.destination) {
      setMessage(t("booking.locationRequired"))
      return
    }
    void machine.calculateRoutes()
  }
  const defaultOrigin: Place = {
    id: "bordeaux-center",
    name: t("booking.currentLocation"),
    address: t("home.mapHint"),
    ...BORDEAUX_CENTER,
  }

  return (
    <div className="step-stack">
      <LocationPicker
        label={t("booking.origin")}
        placeholder={t("booking.originPlaceholder")}
        value={machine.draft.origin}
        onSelect={(origin) => machine.setDraft({ origin })}
        allowCurrent
        onCurrent={useLocation}
      />
      {!machine.draft.origin && (
        <Button
          variant="secondary"
          full
          onClick={() => machine.setDraft({ origin: defaultOrigin })}
        >
          <MapPin aria-hidden="true" />
          {t("home.mapHint")}
        </Button>
      )}
      {machine.draft.intermediateStops.map((stop, index) => (
        <div className="selected-stop" key={`${stop.id}-${index}`}>
          <span className="stop-index mono">{index + 1}</span>
          <span>
            <strong>{t("booking.stop", { number: index + 1 })}</strong>
            <small>{stop.name}</small>
          </span>
          <IconButton
            onClick={() =>
              machine.setDraft({
                intermediateStops: machine.draft.intermediateStops.filter(
                  (_, itemIndex) => itemIndex !== index,
                ),
              })
            }
            aria-label={t("booking.removeStop")}
          >
            <X aria-hidden="true" />
          </IconButton>
        </div>
      ))}
      {addingStop && (
        <LocationPicker
          label={t("booking.stop", {
            number: machine.draft.intermediateStops.length + 1,
          })}
          placeholder={t("booking.destinationPlaceholder")}
          value={null}
          onSelect={(place) => {
            machine.setDraft({
              intermediateStops: [...machine.draft.intermediateStops, place],
            })
            setAddingStop(false)
          }}
        />
      )}
      {machine.draft.intermediateStops.length < 3 && !addingStop && (
        <Button variant="ghost" full onClick={() => setAddingStop(true)}>
          <Plus aria-hidden="true" />
          {t("booking.addStop")}
        </Button>
      )}
      <LocationPicker
        label={t("booking.destination")}
        placeholder={t("booking.destinationPlaceholder")}
        value={machine.draft.destination}
        onSelect={(destination) => machine.setDraft({ destination })}
      />
      <PlaceGroups
        saved={state.savedPlaces}
        recent={machine.recentPlaces}
        onSelect={(destination) => machine.setDraft({ destination })}
      />
      {(message || machine.error) && (
        <p className="inline-error" role="alert">
          <AlertTriangle aria-hidden="true" />
          {machine.error ? t("route.error") : message}
        </p>
      )}
      <Button full onClick={continueToRoute} disabled={machine.busy}>
        {machine.busy ? (
          <Search className="spin" aria-hidden="true" />
        ) : (
          <Route aria-hidden="true" />
        )}
        {machine.busy ? t("route.loading") : t("booking.calculateRoute")}
      </Button>
    </div>
  )
}

function PlaceGroups({
  saved,
  recent,
  onSelect,
}: {
  saved: Place[]
  recent: Place[]
  onSelect: (place: Place) => void
}) {
  const { t } = useI18n()
  return (
    <div className="place-groups">
      <PlaceGroup
        title={t("booking.savedPlaces")}
        empty={t("booking.noSavedPlaces")}
        places={saved}
        onSelect={onSelect}
      />
      <PlaceGroup
        title={t("booking.recentPlaces")}
        empty={t("booking.noRecentPlaces")}
        places={recent}
        onSelect={onSelect}
      />
    </div>
  )
}

function PlaceGroup({
  title,
  empty,
  places,
  onSelect,
}: {
  title: string
  empty: string
  places: Place[]
  onSelect: (place: Place) => void
}) {
  return (
    <section className="place-group">
      <h3>{title}</h3>
      {places.length ? (
        places.map((place) => (
          <button key={place.id} type="button" onClick={() => onSelect(place)}>
            <MapPin aria-hidden="true" />
            <span>{place.name}</span>
            <ChevronRight className="directional-icon" aria-hidden="true" />
          </button>
        ))
      ) : (
        <p>{empty}</p>
      )}
    </section>
  )
}

function RouteStep({ machine }: { machine: BookingMachine }) {
  const { t, locale } = useI18n()
  return (
    <div className="step-stack">
      <div className="route-list" role="radiogroup">
        {machine.draft.routes.map((route, index) => (
          <button
            type="button"
            role="radio"
            aria-checked={route.id === machine.draft.selectedRouteId}
            className={
              route.id === machine.draft.selectedRouteId ? "is-selected" : ""
            }
            key={route.id}
            onClick={() => machine.setDraft({ selectedRouteId: route.id })}
          >
            <span className="route-icon">
              <Route aria-hidden="true" />
            </span>
            <span>
              <strong>
                {index === 0
                  ? t("route.fastest")
                  : t("route.alternative", { number: index })}
              </strong>
              <small>
                <bdi>{formatDistance(route.distanceKm, locale)}</bdi>
                <bdi>
                  {t("route.duration", {
                    duration: Math.round(route.durationMin),
                  })}
                </bdi>
              </small>
            </span>
            {route.id === machine.draft.selectedRouteId && (
              <Check aria-hidden="true" />
            )}
          </button>
        ))}
      </div>
      <Button full onClick={() => machine.setDraft({ step: "vehicle" })}>
        {t("route.continue")}
        <ChevronRight className="directional-icon" aria-hidden="true" />
      </Button>
    </div>
  )
}

function VehicleStep({ machine }: { machine: BookingMachine }) {
  const { t, locale } = useI18n()
  const vehicles = VEHICLES.filter(
    (vehicle) => !machine.draft.electricOnly || vehicle.id === "elec",
  )
  return (
    <div className="step-stack">
      <div className="filter-grid">
        <Switch
          checked={machine.draft.electricOnly}
          onChange={(electricOnly) => machine.setDraft({ electricOnly })}
          label={t("vehicle.electricOnly")}
        />
        <Switch
          checked={machine.draft.carpool}
          onChange={(carpool) => machine.setDraft({ carpool })}
          label={t("vehicle.carpool")}
          description={t("vehicle.carpoolSaving")}
        />
        <Switch
          checked={machine.draft.womenOnly}
          onChange={(womenOnly) => machine.setDraft({ womenOnly })}
          label={t("vehicle.womenOnly")}
          description={t("vehicle.womenOnlyHint")}
        />
      </div>
      <div className="vehicle-list" role="radiogroup">
        {vehicles.map((vehicle) => {
          const fare = machine.fareFor(vehicle.id)
          const selected = machine.draft.vehicleTypeId === vehicle.id
          return (
            <button
              type="button"
              role="radio"
              aria-checked={selected}
              className={selected ? "is-selected" : ""}
              key={vehicle.id}
              onClick={() => machine.setDraft({ vehicleTypeId: vehicle.id })}
            >
              <span className="vehicle-glyph">
                <VehicleGlyph />
                {vehicle.id === "elec" && <Leaf aria-hidden="true" />}
              </span>
              <span className="vehicle-copy">
                <strong>{t(vehicle.nameKey as never)}</strong>
                <small>
                  <span>
                    <Users aria-hidden="true" />
                    {t("vehicle.capacity", { count: vehicle.capacity })}
                  </span>
                  <span>
                    <Clock3 aria-hidden="true" />
                    {t("vehicle.eta", { minutes: vehicle.baseEtaMin })}
                  </span>
                </small>
              </span>
              <strong className="price" dir="ltr">
                {fare ? formatMoney(fare.total, locale) : "—"}
              </strong>
            </button>
          )
        })}
      </div>
      <Button full onClick={() => machine.setDraft({ step: "confirm" })}>
        {t("vehicle.continue", {
          vehicle: t(machine.selectedVehicle.nameKey as never),
        })}
      </Button>
    </div>
  )
}

function ConfirmStep({ machine }: { machine: BookingMachine }) {
  const { t, locale } = useI18n()
  const { state } = useAppState()
  const [promo, setPromo] = useState("")
  const [promoMessage, setPromoMessage] = useState("")
  const [scheduleLater, setScheduleLater] = useState(
    !!machine.draft.scheduledFor,
  )
  const fare = machine.fare
  if (!fare || !machine.selectedRoute) return null
  const applyPromo = () => {
    const normalized = promo.trim().toUpperCase()
    if (normalized !== "RIDE20") {
      setPromoMessage(t("confirm.promoInvalid"))
      return
    }
    if (state.usedPromoCodes.includes(normalized)) {
      setPromoMessage(t("confirm.promoUsed"))
      return
    }
    machine.setDraft({ promoCode: normalized })
    setPromoMessage(t("confirm.promoApplied"))
  }
  const minimum = new Date(Date.now() + 15 * 60_000)
  const maximum = new Date(Date.now() + 30 * 24 * 60 * 60_000)
  const localValue = (date: Date) =>
    new Date(date.getTime() - date.getTimezoneOffset() * 60_000)
      .toISOString()
      .slice(0, 16)
  return (
    <div className="step-stack">
      <section className="fare-card">
        <h3>{t("confirm.fare")}</h3>
        <FareLine label={t("confirm.base")} value={fare.base} locale={locale} />
        <FareLine
          label={t("confirm.distance")}
          value={fare.distance}
          locale={locale}
        />
        <FareLine
          label={t("confirm.duration")}
          value={fare.duration}
          locale={locale}
        />
        {fare.stops > 0 && (
          <FareLine
            label={t("confirm.stops")}
            value={fare.stops}
            locale={locale}
          />
        )}
        {fare.surge > 1 && (
          <FareLine
            label={t("confirm.surge", { surge: fare.surge })}
            value={
              (fare.base + fare.distance + fare.duration) * (fare.surge - 1)
            }
            locale={locale}
          />
        )}
        {fare.discount > 0 && (
          <FareLine
            label={t("confirm.discount")}
            value={-fare.discount}
            locale={locale}
          />
        )}
        <div className="fare-total">
          <strong>{t("confirm.total")}</strong>
          <strong className="price" dir="ltr">
            {formatMoney(fare.total, locale)}
          </strong>
        </div>
        <p>
          <Clock3 aria-hidden="true" />
          {t("confirm.locked")}
        </p>
      </section>
      <div className="promo-row">
        <TextField
          label={t("confirm.promo")}
          placeholder={t("confirm.promoPlaceholder")}
          value={promo}
          onChange={(event) => setPromo(event.target.value)}
        />
        <Button variant="secondary" onClick={applyPromo}>
          {t("confirm.apply")}
        </Button>
      </div>
      {promoMessage && (
        <p
          className={
            machine.draft.promoCode ? "inline-success" : "inline-error"
          }
          role="status"
        >
          {promoMessage}
        </p>
      )}
      <section className="confirm-section">
        <h3>
          <CreditCard aria-hidden="true" />
          {t("confirm.payment")}
        </h3>
        <button type="button" className="selection-tile is-selected">
          <CircleDollarSign aria-hidden="true" />
          <span>{t("confirm.cash")}</span>
          <Check aria-hidden="true" />
        </button>
      </section>
      <section className="confirm-section">
        <h3>
          <Users aria-hidden="true" />
          {t("confirm.split")}
        </h3>
        <div className="segmented">
          {([1, 2, 3, 4] as const).map((count) => (
            <button
              type="button"
              className={
                machine.draft.splitCount === count ? "is-selected" : ""
              }
              key={count}
              onClick={() => machine.setDraft({ splitCount: count })}
            >
              <bdi>×{count}</bdi>
            </button>
          ))}
        </div>
      </section>
      <section className="confirm-section">
        <h3>
          <CalendarClock aria-hidden="true" />
          {t("confirm.schedule")}
        </h3>
        <div className="segmented">
          <button
            type="button"
            className={!scheduleLater ? "is-selected" : ""}
            onClick={() => {
              setScheduleLater(false)
              machine.setDraft({ scheduledFor: null })
            }}
          >
            {t("confirm.now")}
          </button>
          <button
            type="button"
            className={scheduleLater ? "is-selected" : ""}
            onClick={() => setScheduleLater(true)}
          >
            {t("confirm.later")}
          </button>
        </div>
        {scheduleLater && (
          <TextField
            label={t("confirm.scheduleHint")}
            type="datetime-local"
            min={localValue(minimum)}
            max={localValue(maximum)}
            value={
              machine.draft.scheduledFor?.slice(0, 16) ?? localValue(minimum)
            }
            onChange={(event) =>
              machine.setDraft({
                scheduledFor: new Date(event.target.value).toISOString(),
              })
            }
          />
        )}
      </section>
      <Button full onClick={machine.createRide}>
        {t("confirm.confirm", { price: formatMoney(fare.total, locale) })}
      </Button>
    </div>
  )
}

function FareLine({
  label,
  value,
  locale,
}: {
  label: string
  value: number
  locale: Parameters<typeof formatMoney>[1]
}) {
  return (
    <div className="fare-line">
      <span>{label}</span>
      <bdi className="mono">{formatMoney(value, locale)}</bdi>
    </div>
  )
}

function SearchingStep({ machine }: { machine: BookingMachine }) {
  const { t } = useI18n()
  const { state } = useAppState()
  const [candidate, setCandidate] =
    useState<Awaited<ReturnType<BookingMachine["findDriver"]>>>(null)
  const [excluded, setExcluded] = useState<string[]>([])
  const [seconds, setSeconds] = useState(20)

  useEffect(() => {
    if (!candidate) void machine.findDriver(excluded).then(setCandidate)
  }, [candidate, excluded, machine.activeRide?.id])

  useEffect(() => {
    if (!candidate) return
    const timer = window.setInterval(() => {
      setSeconds((current) => Math.max(0, current - state.speed))
    }, 1000)
    return () => window.clearInterval(timer)
  }, [candidate, state.speed])

  useEffect(() => {
    if (!candidate) return
    if (excluded.length > 0 && seconds <= 16) {
      machine.assignDriver(candidate)
      return
    }
    if (seconds === 0) {
      setExcluded((items) => [...items, candidate.id])
      setCandidate(null)
      setSeconds(20)
    }
  }, [seconds, candidate, excluded.length])

  return (
    <div className="search-state">
      <motion.div className="search-radar" aria-hidden="true">
        <span />
        <span />
        <Search />
      </motion.div>
      <h2>{t("search.title")}</h2>
      <p>{t("search.description")}</p>
      {candidate && (
        <div className="candidate-card">
          <span>{candidate.name.slice(0, 1)}</span>
          <div>
            <strong>{t("search.candidate", { driver: candidate.name })}</strong>
            <small>{t("search.next", { seconds })}</small>
          </div>
          <bdi className="countdown mono">{seconds}</bdi>
        </div>
      )}
      {excluded.length > 0 && (
        <p className="inline-success">{t("search.noResponse")}</p>
      )}
      <Button variant="danger" full onClick={machine.cancelRide}>
        {t("search.cancel")}
      </Button>
      <small>{t("search.cancelFree")}</small>
    </div>
  )
}

function AssignedStep({ machine }: { machine: BookingMachine }) {
  const { t } = useI18n()
  const { state } = useAppState()
  const driver = DRIVERS.find(
    (item) => item.id === machine.draft.assignedDriverId,
  )
  const [seconds, setSeconds] = useState(
    machine.selectedVehicle.baseEtaMin * 60,
  )
  useEffect(() => {
    const timer = window.setInterval(
      () => setSeconds((value) => Math.max(0, value - state.speed)),
      1000,
    )
    return () => window.clearInterval(timer)
  }, [state.speed])
  if (!driver) return null
  return (
    <div className="step-stack">
      <section className="driver-card">
        <span className="driver-avatar">{driver.name.slice(0, 1)}</span>
        <div>
          <h2>{driver.name}</h2>
          <p>
            {driver.vehicle} · {driver.color}
          </p>
          <strong>
            <Star aria-hidden="true" />
            {driver.rating.toFixed(2)}
          </strong>
        </div>
        <bdi className="eta-badge mono">
          {String(Math.floor(seconds / 60)).padStart(2, "0")}:
          {String(seconds % 60).padStart(2, "0")}
        </bdi>
      </section>
      <div className="trip-codes">
        <div>
          <small>{t("assigned.plate")}</small>
          <bdi className="plate">{driver.plate}</bdi>
        </div>
        <div>
          <small>{t("assigned.pin")}</small>
          <bdi className="pin">{machine.draft.pin}</bdi>
        </div>
      </div>
      <p className="pin-hint">{t("assigned.pinHint")}</p>
      <Button
        full
        onClick={() => {
          machine.startRide()
        }}
      >
        {t("assigned.start")}
      </Button>
      <Button variant="ghost" full onClick={machine.cancelRide}>
        {t("assigned.cancel")}
      </Button>
    </div>
  )
}

function ProgressStep({ machine }: { machine: BookingMachine }) {
  const { t } = useI18n()
  const [message, setMessage] = useState("")
  const share = async () => {
    const text = t("progress.shareText", { ride: machine.activeRide?.id ?? "" })
    try {
      if (navigator.share) await navigator.share({ text })
      else await navigator.clipboard.writeText(text)
      setMessage(t("progress.shared"))
    } catch {
      setMessage("")
    }
  }
  return (
    <div className="step-stack">
      <section className="live-card">
        <span className="live-dot" />
        <div>
          <strong>{t("progress.live")}</strong>
          <small>{machine.draft.destination?.name}</small>
        </div>
      </section>
      <div className="safety-actions">
        <Button variant="secondary" onClick={share}>
          <Share2 aria-hidden="true" />
          {t("progress.share")}
        </Button>
        <Button
          variant="danger"
          onClick={() => {
            machine.setDraft({ sos: true })
            machine.setSos()
            setMessage(t("progress.sosActive"))
          }}
        >
          <ShieldAlert aria-hidden="true" />
          {t("progress.sos")}
        </Button>
      </div>
      {message && (
        <p
          className={machine.draft.sos ? "inline-error" : "inline-success"}
          role="status"
        >
          {message}
        </p>
      )}
      <Button full onClick={machine.finishRide}>
        {t("progress.finish")}
      </Button>
    </div>
  )
}

function CompleteStep({ machine }: { machine: BookingMachine }) {
  const { t, locale } = useI18n()
  return (
    <div className="complete-state">
      <span className="success-mark">
        <Check aria-hidden="true" />
      </span>
      <h2>{t("complete.title")}</h2>
      <p>{t("complete.description")}</p>
      <fieldset className="rating-field">
        <legend>{t("complete.rating")}</legend>
        <div>
          {([1, 2, 3, 4, 5] as const).map((rating) => (
            <button
              type="button"
              aria-label={String(rating)}
              key={rating}
              className={
                (machine.draft.rating ?? 0) >= rating ? "is-selected" : ""
              }
              onClick={() => machine.setDraft({ rating })}
            >
              <Star aria-hidden="true" />
            </button>
          ))}
        </div>
      </fieldset>
      <fieldset className="tip-field">
        <legend>{t("complete.tip")}</legend>
        <div className="segmented">
          {([0, 1, 2, 3, 5] as const).map((tip) => (
            <button
              type="button"
              key={tip}
              className={machine.draft.tip === tip ? "is-selected" : ""}
              onClick={() => machine.setDraft({ tip })}
            >
              {tip === 0 ? (
                t("complete.noTip")
              ) : (
                <bdi>{formatMoney(tip, locale)}</bdi>
              )}
            </button>
          ))}
        </div>
      </fieldset>
      <Button
        full
        onClick={machine.submitReview}
        disabled={!machine.draft.rating}
      >
        {t("complete.submit")}
      </Button>
    </div>
  )
}

function ReceiptStep({ machine }: { machine: BookingMachine }) {
  const { t, locale } = useI18n()
  const { state } = useAppState()
  const ride = machine.activeRide
  if (!ride) return null
  const completedCount = state.rides.filter(
    (item) => item.status === "completed",
  ).length
  const tier =
    [...LOYALTY_TIERS]
      .reverse()
      .find((item) => completedCount >= item.ridesRequired) ?? LOYALTY_TIERS[0]!
  return (
    <div className="step-stack">
      <section className="receipt-card">
        <span className="receipt-icon">
          <ReceiptText aria-hidden="true" />
        </span>
        <h2>
          {t(
            ride.status === "scheduled"
              ? "receipt.scheduledTitle"
              : "receipt.title",
          )}
        </h2>
        <strong className="receipt-total" dir="ltr">
          {formatMoney(ride.fare.total + ride.tip, locale)}
        </strong>
        <div>
          <span>{t("booking.origin")}</span>
          <strong>{ride.stops[0]?.name}</strong>
        </div>
        <div>
          <span>{t("booking.destination")}</span>
          <strong>{ride.stops.at(-1)?.name}</strong>
        </div>
        <div>
          <span>{t("receipt.date")}</span>
          <bdi>
            {new Intl.DateTimeFormat(localeTags[locale], {
              dateStyle: "medium",
              timeStyle: "short",
            }).format(
              new Date(ride.scheduledFor ?? ride.completedAt ?? ride.createdAt),
            )}
          </bdi>
        </div>
        <div>
          <span>{t("receipt.rideId")}</span>
          <bdi className="mono receipt-id">{ride.id}</bdi>
        </div>
      </section>
      <section className="loyalty-card">
        <div>
          <BatteryCharging aria-hidden="true" />
          <span>
            <strong>{t("loyalty.title")}</strong>
            <small>{t("loyalty.rides", { count: completedCount })}</small>
          </span>
        </div>
        <bdi>{t("loyalty.tier", { tier: tier.id })}</bdi>
      </section>
      <Button full onClick={machine.reset}>
        {t("receipt.newRide")}
      </Button>
    </div>
  )
}

function stepTitle(step: BookingStep, t: ReturnType<typeof useI18n>["t"]) {
  const keys: Record<BookingStep, Parameters<typeof t>[0]> = {
    locations: "home.destinationLabel",
    route: "route.title",
    vehicle: "vehicle.title",
    confirm: "confirm.title",
    searching: "search.title",
    assigned: "assigned.title",
    in_progress: "progress.title",
    complete: "complete.title",
    receipt: "receipt.title",
  }
  return t(keys[step])
}
