import { useEffect, useState } from "react"
import { geocodingProvider } from "../../integrations/geocoding"
import type { Place } from "../../types"

export type SearchState = "idle" | "loading" | "success" | "empty" | "error"

export function usePlaceSearch(query: string) {
  const [results, setResults] = useState<Place[]>([])
  const [status, setStatus] = useState<SearchState>("idle")

  useEffect(() => {
    const normalized = query.trim()
    if (!normalized) {
      setResults([])
      setStatus("idle")
      return
    }
    let active = true
    setStatus("loading")
    const timer = window.setTimeout(async () => {
      try {
        const places = await geocodingProvider.search(normalized)
        if (!active) return
        setResults(places)
        setStatus(places.length ? "success" : "empty")
      } catch {
        if (active) setStatus("error")
      }
    }, 450)
    return () => {
      active = false
      window.clearTimeout(timer)
    }
  }, [query])

  return { results, status }
}
