import { LoaderCircle, LocateFixed, MapPin } from "lucide-react"
import { useState } from "react"
import { Button } from "../../components/ui/Button"
import { TextField } from "../../components/ui/TextField"
import { useI18n } from "../../i18n"
import type { Place } from "../../types"
import { usePlaceSearch } from "./usePlaceSearch"

export function LocationPicker({
  label,
  placeholder,
  value,
  onSelect,
  allowCurrent = false,
  onCurrent,
}: {
  label: string
  placeholder: string
  value: Place | null
  onSelect: (place: Place) => void
  allowCurrent?: boolean
  onCurrent?: () => void
}) {
  const { t } = useI18n()
  const [query, setQuery] = useState("")
  const { results, status } = usePlaceSearch(query)

  return (
    <div className="location-picker">
      <TextField
        label={label}
        placeholder={value?.name ?? placeholder}
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        icon={<MapPin aria-hidden="true" />}
        autoComplete="off"
      />
      {allowCurrent && onCurrent && (
        <Button variant="ghost" full onClick={onCurrent}>
          <LocateFixed aria-hidden="true" />
          {t("booking.currentLocation")}
        </Button>
      )}
      {status !== "idle" && (
        <div className="autocomplete" role="listbox">
          {status === "loading" && (
            <p role="status">
              <LoaderCircle className="spin" aria-hidden="true" />
              {t("booking.searchLoading")}
            </p>
          )}
          {status === "empty" && <p>{t("booking.searchEmpty")}</p>}
          {status === "error" && <p role="alert">{t("booking.searchError")}</p>}
          {status === "success" &&
            results.map((place) => (
              <button
                type="button"
                role="option"
                key={place.id}
                onClick={() => {
                  onSelect(place)
                  setQuery("")
                }}
              >
                <MapPin aria-hidden="true" />
                <span>
                  <strong>{place.name}</strong>
                  <small>{place.address}</small>
                </span>
              </button>
            ))}
        </div>
      )}
    </div>
  )
}
