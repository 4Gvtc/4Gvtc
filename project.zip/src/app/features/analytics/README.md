# Analytics
Metrics computed from actual store data.
